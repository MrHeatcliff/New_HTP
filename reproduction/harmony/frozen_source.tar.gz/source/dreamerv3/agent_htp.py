"""
DreamerV3 agent with Hierarchical Temporal Prefix World Model (HTP-WM).

Extended in this revision to support Slim-HTP and related ablations via two
new config flags:

    agent.htp.use_proj      (default: true)
        If false, skip the learned projection S_ψ. z_t becomes an alias for h_t.
        Actor, critic, reward, and continuation heads consume h_t directly.
        The slow projection is also skipped.

    agent.htp.use_recon     (default: true)
        If false, skip the progressive reconstruction loss (htp_recon).
        Only useful when use_proj is also false; with a projection present,
        htp_recon is meaningful even if downweighted via loss scales.

    agent.htp.use_vicreg    (default: false)
        If true, add a lightweight variance regularizer on each prefix that
        prevents collapse. Useful when use_proj=false and use_recon=false
        (Slim-HTP), since neither slow-target nor recon anti-collapse
        mechanisms are present. Also applies when the projection is on.

Config matrix supported by this file (all with htp.enabled=true):

    use_proj  use_recon  What it is
    ─────────────────────────────────────────────────────────────────────
    true      true       Original HTP-WM as in the paper (htp_full)
    true      false      Projection kept, recon dropped (htp_pdyn_only)
    false     false      Slim-HTP: pdyn on h_t prefixes, no projection,
                         no recon. Requires grad_to_backbone=true to have
                         any effect on control.
    false     true       NOT SUPPORTED. Reconstructing h_t from prefixes
                         of h_t is degenerate ("copy yourself" trivial
                         component). Raises at construction time.

Setting htp.enabled=false restores vanilla DreamerV3 behaviour.
"""

import re

import chex
import elements
import embodied.jax
import embodied.jax.nets as nn
import jax
import jax.numpy as jnp
import ninjax as nj
import numpy as np
import optax

from . import htp as htp_mod
from . import rssm

f32 = jnp.float32
i32 = jnp.int32
sg = lambda xs, skip=False: xs if skip else jax.lax.stop_gradient(xs)
sample = lambda xs: jax.tree.map(lambda x: x.sample(nj.seed()), xs)
prefix_fn = lambda xs, p: {f'{p}/{k}': v for k, v in xs.items()}
concat = lambda xs, a: jax.tree.map(lambda *x: jnp.concatenate(x, a), *xs)
isimage = lambda s: s.dtype == np.uint8 and len(s.shape) == 3


class Agent_HTP(embodied.jax.Agent):

  banner = [
      r"---  ___                           __   ______   __ __ ______ ___  ---",
      r"--- |   \ _ _ ___ __ _ _ __  ___ _ \ \ / /__ / _|  |  | |_   _| _ \---",
      r"--- | |) | '_/ -_) _` | '  \/ -_) '/\ V / |_ \|_ ||_|_  | | | |  _/---",
      r"--- |___/|_| \___\__,_|_|_|_\___|_|  \_/ |___/    |___| |_| |_|_|  ---",
  ]

  def __init__(self, obs_space, act_space, config):
    self.obs_space = obs_space
    self.act_space = act_space
    self.config = config

    exclude = ('is_first', 'is_last', 'is_terminal', 'reward')
    enc_space = {k: v for k, v in obs_space.items() if k not in exclude}
    dec_space = {k: v for k, v in obs_space.items() if k not in exclude}
    self.enc = {
        'simple': rssm.Encoder,
    }[config.enc.typ](enc_space, **config.enc[config.enc.typ], name='enc')
    self.dyn = {
        'rssm': rssm.RSSM,
    }[config.dyn.typ](act_space, **config.dyn[config.dyn.typ], name='dyn')
    self.dec = {
        'simple': rssm.Decoder,
    }[config.dec.typ](dec_space, **config.dec[config.dec.typ], name='dec')

    # ------------------------------------------------------------------ HTP-WM
    dyn_cfg = config.dyn[config.dyn.typ]
    self.feat_dim = int(dyn_cfg['deter'] + dyn_cfg['stoch'] * dyn_cfg['classes'])

    htp_cfg = config.htp
    self.htp_enabled  = bool(htp_cfg.enabled)
    self.htp_use_proj = bool(htp_cfg.get('use_proj',  True))
    self.htp_use_recon = bool(htp_cfg.get('use_recon', True))
    self.htp_use_pdyn = bool(htp_cfg.get('use_pdyn', True))
    self.htp_use_vicreg = bool(htp_cfg.get('use_vicreg', False))
    experimental_scales = [float(htp_cfg.get(key, 0.0)) for key in (
        'persistence_scale', 'persistence_isotropy', 'persistence_decorrelation',
        'persistence_block2_rank_scale')]
    if any(not np.isfinite(x) or x < 0 for x in experimental_scales):
      raise ValueError('Persistence regularizer scales must be finite and nonnegative')
    if any(experimental_scales) and not (self.htp_enabled and self.htp_use_pdyn):
      raise ValueError('Persistence regularizers require enabled HTP prefix dynamics')
    if float(htp_cfg.get('persistence_decorrelation', 0.0)) and len(htp_cfg.proj.dims) < 2:
      raise ValueError('Block decorrelation requires at least two prefix blocks')
    if float(htp_cfg.get('persistence_block2_rank_scale', 0.0)):
      if len(htp_cfg.proj.dims) < 2:
        raise ValueError('Second-block rank guard requires two blocks')
      floor = float(htp_cfg.get('persistence_block2_min_rank', 8.0))
      width = int(htp_cfg.proj.dims[1]) - int(htp_cfg.proj.dims[0])
      if not np.isfinite(floor) or not 1 < floor <= width:
        raise ValueError('Second-block min rank must be finite and in (1, block width]')
    min_rank = float(htp_cfg.get('persistence_min_rank', 0.0))
    if not np.isfinite(min_rank) or (min_rank != 0 and not 1 < min_rank <= int(htp_cfg.proj.dims[0])):
      raise ValueError('persistence_min_rank must be zero or in (1, first prefix dimension]')
    self.htp_vicreg_gamma = float(htp_cfg.get('vicreg_gamma', 1.0))
    self.htp_vicreg_scale = float(htp_cfg.get('vicreg_scale', 1.0))

    # Guard against the unsupported combination.
    if self.htp_enabled and (not self.htp_use_proj) and self.htp_use_recon:
      raise ValueError(
          "htp.use_proj=false with htp.use_recon=true is not supported: "
          "reconstructing h_t from prefixes of h_t is trivially degenerate. "
          "Set htp.use_recon=false when disabling the projection, or use the "
          "VICReg regularizer for anti-collapse instead.")

    if self.htp_enabled:
      # ---- Projection (optional) ----
      if self.htp_use_proj:
        self.htp_proj = htp_mod.OrderedProjection(
            **htp_cfg.proj, name='htp_proj')
        self.slow_htp_proj = embodied.jax.SlowModel(
            htp_mod.OrderedProjection(**htp_cfg.proj, name='slow_htp_proj'),
            source=self.htp_proj, **config.slowhtp)
        self.repr_dim = int(self.htp_proj.output_dim)
      else:
        self.htp_proj = None
        self.slow_htp_proj = None
        self.repr_dim = self.feat_dim

      # ---- Progressive reconstruction (optional) ----
      if self.htp_use_recon:
        self.htp_recon = htp_mod.ProgressiveRecon(
            feat_dim=12288 if htp_cfg.recon.image_target else self.feat_dim,
            **htp_cfg.recon, name='htp_recon')
      else:
        self.htp_recon = None

      # ---- Multi-stride prefix dynamics (always present when HTP is on) ----
      # When use_proj=false, pdyn.dims must sum-boundary-wise fit inside
      # feat_dim rather than proj.output_dim. The user is responsible for
      # setting agent.htp.pdyn.dims accordingly in configs.yaml.
      self.htp_pdyn = (htp_mod.MultiStridePDyn(
          **htp_cfg.pdyn, name='htp_pdyn') if self.htp_use_pdyn else None)

      # Sanity check on pdyn.dims when there's no projection.
      if not self.htp_use_proj:
        max_dim = max(htp_cfg.pdyn.dims)
        if max_dim > self.feat_dim:
          raise ValueError(
              f"htp.pdyn.dims max ({max_dim}) exceeds feat_dim ({self.feat_dim}). "
              f"When use_proj=false, prefix boundaries must fit inside h_t. "
              f"Suggested dims for feat_dim={self.feat_dim}: "
              f"[128, 512, 2048, 5120, {self.feat_dim}]")
    else:
      self.htp_proj = None
      self.slow_htp_proj = None
      self.htp_recon = None
      self.htp_pdyn = None
      self.repr_dim = self.feat_dim
    # -----------------------------------------------------------------------

    scalar = elements.Space(np.float32, ())
    binary = elements.Space(bool, (), 0, 2)
    self.rew = embodied.jax.MLPHead(scalar, **config.rewhead, name='rew')
    self.con = embodied.jax.MLPHead(binary, **config.conhead, name='con')

    d1, d2 = config.policy_dist_disc, config.policy_dist_cont
    outs = {k: d1 if v.discrete else d2 for k, v in act_space.items()}
    self.pol = embodied.jax.MLPHead(
        act_space, outs, **config.policy, name='pol')

    self.val = embodied.jax.MLPHead(scalar, **config.value, name='val')
    self.slowval = embodied.jax.SlowModel(
        embodied.jax.MLPHead(scalar, **config.value, name='slowval'),
        source=self.val, **config.slowvalue)

    self.retnorm = embodied.jax.Normalize(**config.retnorm, name='retnorm')
    self.valnorm = embodied.jax.Normalize(**config.valnorm, name='valnorm')
    self.advnorm = embodied.jax.Normalize(**config.advnorm, name='advnorm')

    modules = [self.dyn, self.enc, self.dec, self.rew, self.con,
               self.pol, self.val]
    if self.htp_enabled:
      if self.htp_use_pdyn: modules.append(self.htp_pdyn)
      if self.htp_use_proj:  modules.append(self.htp_proj)
      if self.htp_use_recon: modules.append(self.htp_recon)
    self.modules = modules
    self.opt = embodied.jax.Optimizer(
        self.modules, self._make_opt(**config.opt), summary_depth=1,
        name='opt')

    # Loss-scale bookkeeping. Only include HTP scales for losses that will
    # actually be produced.
    scales = self.config.loss_scales.copy()
    rec = scales.pop('rec')
    scales.update({k: rec for k in dec_space})
    if self.htp_enabled:
      if self.htp_use_recon:
        scales.setdefault('htp_rec', 1.0)
      else:
        scales.pop('htp_rec', None)
      if self.htp_use_pdyn:
        scales.setdefault('htp_pdyn', 1.0)
      else:
        scales.pop('htp_pdyn', None)
      if self.htp_use_vicreg:
        scales.setdefault('htp_vicreg', self.htp_vicreg_scale)
      else:
        scales.pop('htp_vicreg', None)
    else:
      scales.pop('htp_rec',    None)
      scales.pop('htp_pdyn',   None)
      scales.pop('htp_vicreg', None)
    self.scales = scales

  # ---------------------------------------------------------------------
  # Representation helpers
  # ---------------------------------------------------------------------

  def feat2h(self, feat):
    """Base world-model latent h_t = [deter, flatten(stoch)] in R^feat_dim."""
    return jnp.concatenate([
        nn.cast(feat['deter']),
        nn.cast(feat['stoch'].reshape((*feat['stoch'].shape[:-2], -1)))], -1)

  def feat2tensor(self, feat):
    """
    Representation supplied to reward, continuation, policy, and value heads.

    Three regimes:
      * htp.enabled=false:                 returns h_t (naive DreamerV3)
      * htp.enabled=true, use_proj=true:   returns z_t = S_ψ(h_t)
      * htp.enabled=true, use_proj=false:  returns h_t (Slim-HTP)
    """
    h = self.feat2h(feat)
    if self.htp_enabled and self.htp_use_proj:
      return self.htp_proj(h)
    return h

  # ---------------------------------------------------------------------

  @property
  def policy_keys(self):
    if self.htp_enabled and self.htp_use_proj:
      return '^(enc|dyn|dec|pol|htp_proj)/'
    return '^(enc|dyn|dec|pol)/'

  @property
  def ext_space(self):
    spaces = {}
    spaces['consec'] = elements.Space(np.int32)
    spaces['stepid'] = elements.Space(np.uint8, 20)
    if self.config.replay_context:
      spaces.update(elements.tree.flatdict(dict(
          enc=self.enc.entry_space,
          dyn=self.dyn.entry_space,
          dec=self.dec.entry_space)))
    return spaces

  def init_policy(self, batch_size):
    zeros = lambda x: jnp.zeros((batch_size, *x.shape), x.dtype)
    return (
        self.enc.initial(batch_size),
        self.dyn.initial(batch_size),
        self.dec.initial(batch_size),
        jax.tree.map(zeros, self.act_space))

  def init_train(self, batch_size):
    return self.init_policy(batch_size)

  def init_report(self, batch_size):
    return self.init_policy(batch_size)

  def policy(self, carry, obs, mode='train'):
    (enc_carry, dyn_carry, dec_carry, prevact) = carry
    kw = dict(training=False, single=True)
    reset = obs['is_first']
    enc_carry, enc_entry, tokens = self.enc(enc_carry, obs, reset, **kw)
    dyn_carry, dyn_entry, feat = self.dyn.observe(
        dyn_carry, tokens, prevact, reset, **kw)
    dec_entry = {}
    if dec_carry:
      dec_carry, dec_entry, recons = self.dec(dec_carry, feat, reset, **kw)
    policy = self.pol(self.feat2tensor(feat), bdims=1)
    act = sample(policy)
    out = {}
    out['finite'] = elements.tree.flatdict(jax.tree.map(
        lambda x: jnp.isfinite(x).all(range(1, x.ndim)),
        dict(obs=obs, carry=carry, tokens=tokens, feat=feat, act=act)))
    carry = (enc_carry, dyn_carry, dec_carry, act)
    if self.config.replay_context:
      out.update(elements.tree.flatdict(dict(
          enc=enc_entry, dyn=dyn_entry, dec=dec_entry)))
    return carry, act, out

  def train(self, carry, data):
    carry, obs, prevact, stepid = self._apply_replay_context(carry, data)
    metrics, (carry, entries, outs, mets) = self.opt(
        self.loss, carry, obs, prevact, training=True, has_aux=True)
    metrics.update(mets)
    self.slowval.update()
    if self.htp_enabled and self.htp_use_proj:
      self.slow_htp_proj.update()
    outs = {}
    if self.config.replay_context:
      updates = elements.tree.flatdict(dict(
          stepid=stepid, enc=entries[0], dyn=entries[1], dec=entries[2]))
      B, T = obs['is_first'].shape
      assert all(x.shape[:2] == (B, T) for x in updates.values()), (
          (B, T), {k: v.shape for k, v in updates.items()})
      outs['replay'] = updates
    carry = (*carry, {k: data[k][:, -1] for k in self.act_space})
    return carry, outs, metrics

  def loss(self, carry, obs, prevact, training):
    enc_carry, dyn_carry, dec_carry = carry
    reset = obs['is_first']
    B, T = reset.shape
    losses = {}
    metrics = {}

    # ------------------------------------------------------- World model core
    enc_carry, enc_entries, tokens = self.enc(
        enc_carry, obs, reset, training)
    dyn_carry, dyn_entries, los, repfeat, mets = self.dyn.loss(
        dyn_carry, tokens, prevact, reset, training)
    losses.update(los)
    metrics.update(mets)
    dec_carry, dec_entries, recons = self.dec(
        dec_carry, repfeat, reset, training)

    # -------------------------------------------------- HTP-WM auxiliary losses
    h_t = self.feat2h(repfeat)  # (B, T, feat_dim)

    if self.htp_enabled:
      # Decide whether HTP gradients reach the RSSM backbone.
      # When use_proj=false, grad_to_backbone MUST be true for the loss to
      # have any effect (there's no projection to absorb gradients).
      if not self.htp_use_proj and not self.config.htp.grad_to_backbone:
        # This is a valid configuration but produces a decorative loss.
        # We honour it (user might want it as a sanity-check arm) but note
        # that pdyn will not shape h_t at all.
        h_for_z = sg(h_t)
      else:
        h_for_z = h_t if self.config.htp.grad_to_backbone else sg(h_t)

      # ---- Compute z_t (online) and z_slow (target) ----
      if self.htp_use_proj:
        z_t     = self.htp_proj(h_for_z)               # (B, T, D)
        z_slow  = self.slow_htp_proj(sg(h_t))          # (B, T, D)
      else:
        z_t     = h_for_z                              # z_t IS h_t
        z_slow  = sg(h_t)                              # target: RSSM's own output

      # ---- Progressive reconstruction (only when use_recon=true) ----
      if self.htp_use_recon:
        target = h_t
        if self.config.htp.recon.image_target:
          if obs['image'].shape[-3:] != (64, 64, 3):
            raise ValueError('Image reconstruction requires 64x64 RGB observations')
          target = (f32(obs['image']) / 255.0).reshape((*h_t.shape[:2], 12288))
        rec_loss, rec_per_level = self.htp_recon(z_t, sg(target), reset=reset)
        losses['htp_rec'] = rec_loss
        for ell, err in enumerate(rec_per_level):
          metrics[f'htp_rec_l{ell}'] = err.mean()

      # ---- Multi-stride prefix dynamics ----
      if self.htp_use_pdyn:
        act_flat_full = htp_mod.flatten_action_dict(prevact, self.act_space)
        pad_last = jnp.zeros_like(act_flat_full[:, :1])
        act_seq_full = jnp.concatenate(
            [act_flat_full[:, 1:], pad_last], axis=1)    # (B, T, A)
        pdyn_loss, pdyn_per_level = self.htp_pdyn(z_t, z_slow, act_seq_full, reset=reset)
        metrics['htp/pdyn_prediction_unscaled'] = pdyn_loss.mean()
        prediction_scale = float(self.config.htp.get('prediction_loss_scale', 1.0))
        if prediction_scale < 0:
          raise ValueError('prediction_loss_scale must be nonnegative')
        pdyn_loss = prediction_scale * pdyn_loss
        metrics['htp/prediction_loss_scale'] = jnp.asarray(prediction_scale)
        losses['htp_pdyn'] = pdyn_loss
        metrics['htp/pdyn_prediction_only'] = pdyn_loss.mean()
        persistence_scale = float(self.config.htp.get('persistence_scale', 0.0))
        if persistence_scale:
          persistence = htp_mod.prefix_persistence(
              z_t, reset, int(self.htp_pdyn.dims[0]),
              int(self.htp_pdyn.strides[0]),
              all_lags=bool(self.config.htp.get('persistence_all_lags', False)),
              metric=self.config.htp.get('persistence_metric', 'pooled'))
          losses['htp_pdyn'] = pdyn_loss + persistence_scale * persistence
          metrics['htp/prefix_persistence'] = persistence
        isotropy_scale = float(self.config.htp.get('persistence_isotropy', 0.0))
        if isotropy_scale:
          isotropy = htp_mod.prefix_isotropy(z_t, int(self.htp_pdyn.dims[0]))
          min_rank = float(self.config.htp.get('persistence_min_rank', 0.0))
          diversity = (htp_mod.prefix_rank_floor(z_t, int(self.htp_pdyn.dims[0]), min_rank)
                       if min_rank else isotropy)
          losses['htp_pdyn'] = losses['htp_pdyn'] + isotropy_scale * diversity
          metrics['htp/prefix_isotropy'] = isotropy
          metrics['htp/prefix_diversity_penalty'] = diversity
        decorrelation_scale = float(self.config.htp.get('persistence_decorrelation', 0.0))
        if decorrelation_scale:
          redundancy = htp_mod.prefix_block_redundancy(
              z_t, int(self.htp_pdyn.dims[0]), int(self.htp_pdyn.dims[1]))
          losses['htp_pdyn'] = losses['htp_pdyn'] + decorrelation_scale * redundancy
          metrics['htp/block12_redundancy'] = redundancy
        block2_rank_scale = float(self.config.htp.get('persistence_block2_rank_scale', 0.0))
        if decorrelation_scale or block2_rank_scale:
          second = z_t[..., int(self.htp_pdyn.dims[0]):int(self.htp_pdyn.dims[1])]
          rank = htp_mod.prefix_participation_rank(second, second.shape[-1])
          metrics['htp/block2_effective_rank'] = rank
          if block2_rank_scale:
            floor = float(self.config.htp.get('persistence_block2_min_rank', 8.0))
            guard = htp_mod.prefix_rank_floor(second, second.shape[-1], floor)
            losses['htp_pdyn'] = losses['htp_pdyn'] + block2_rank_scale * guard
            metrics['htp/block2_rank_guard'] = guard
            metrics['htp/block2_rank_guard_active'] = f32(rank < floor)
        for info in pdyn_per_level:
          metrics[f'htp_pdyn_delta{int(info["stride"])}'] = info['err_mean']
          if 'cross_episode_fraction' in info:
            metrics[f'htp/cross_episode_delta{int(info["stride"])}'] = info['cross_episode_fraction']

      # ---- VICReg-style variance regularizer (Slim-HTP anti-collapse) ----
      if self.htp_use_vicreg:
        # For each prefix level, penalise any prefix coordinate whose batch
        # std falls below gamma. Prevents any coord from collapsing to a
        # constant across the batch/time axis.
        vic_terms = []
        # Work on z_t (which is h_t when use_proj=false, or the projection
        # otherwise). Using z_t means we regularise whatever the heads see.
        for ell, d_ell in enumerate(self.htp_pdyn.dims):
          prefix_ell = z_t[..., :int(d_ell)]                     # (B, T, d_ell)
          flat = prefix_ell.reshape((-1, int(d_ell)))            # (B*T, d_ell)
          std = jnp.sqrt(flat.var(axis=0) + 1e-4)                # (d_ell,)
          term = jnp.mean(jax.nn.relu(self.htp_vicreg_gamma - std) ** 2)
          vic_terms.append(term)
          metrics[f'htp_vic_l{ell}_mean_std'] = std.mean()
        vic_loss = jnp.stack(vic_terms).mean()                   # scalar
        # Broadcast to (B, T) so it composes with the other per-timestep losses
        # via the same .mean() aggregation used at the bottom of loss().
        losses['htp_vicreg'] = jnp.full((B, T), vic_loss, dtype=vic_loss.dtype)
    # ------------------------------------------------------------------------

    inp = sg(self.feat2tensor(repfeat), skip=self.config.reward_grad)
    losses['rew'] = self.rew(inp, 2).loss(obs['reward'])
    con = f32(~obs['is_terminal'])
    if self.config.contdisc:
      con *= 1 - 1 / self.config.horizon
    losses['con'] = self.con(self.feat2tensor(repfeat), 2).loss(con)
    for key, recon in recons.items():
      space, value = self.obs_space[key], obs[key]
      assert value.dtype == space.dtype, (key, space, value.dtype)
      target = f32(value) / 255 if isimage(space) else value
      losses[key] = recon.loss(sg(target))

    B, T = reset.shape
    shapes = {k: v.shape for k, v in losses.items()}
    assert all(x == (B, T) for x in shapes.values()), ((B, T), shapes)

    # ------------------------------------------------- Behaviour by imagination
    K = min(self.config.imag_last or T, T)
    H = self.config.imag_length
    starts = self.dyn.starts(dyn_entries, dyn_carry, K)
    policyfn = lambda feat: sample(self.pol(self.feat2tensor(feat), 1))
    _, imgfeat, imgprevact = self.dyn.imagine(starts, policyfn, H, training)
    first = jax.tree.map(
        lambda x: x[:, -K:].reshape((B * K, 1, *x.shape[2:])), repfeat)
    imgfeat = concat([sg(first, skip=self.config.ac_grads), sg(imgfeat)], 1)
    lastact = policyfn(jax.tree.map(lambda x: x[:, -1], imgfeat))
    lastact = jax.tree.map(lambda x: x[:, None], lastact)
    imgact = concat([imgprevact, lastact], 1)
    assert all(x.shape[:2] == (B * K, H + 1) for x in jax.tree.leaves(imgfeat))
    assert all(x.shape[:2] == (B * K, H + 1) for x in jax.tree.leaves(imgact))
    inp = self.feat2tensor(imgfeat)
    los, imgloss_out, mets = imag_loss(
        imgact,
        self.rew(inp, 2).pred(),
        self.con(inp, 2).prob(1),
        self.pol(inp, 2),
        self.val(inp, 2),
        self.slowval(inp, 2),
        self.retnorm, self.valnorm, self.advnorm,
        update=training,
        contdisc=self.config.contdisc,
        horizon=self.config.horizon,
        **self.config.imag_loss)
    losses.update({k: v.mean(1).reshape((B, K)) for k, v in los.items()})
    metrics.update(mets)

    # ------------------------------------------------- Optional replay-value
    if self.config.repval_loss:
      feat = sg(repfeat, skip=self.config.repval_grad)
      last, term, rew = [obs[k] for k in ('is_last', 'is_terminal', 'reward')]
      boot = imgloss_out['ret'][:, 0].reshape(B, K)
      feat, last, term, rew, boot = jax.tree.map(
          lambda x: x[:, -K:], (feat, last, term, rew, boot))
      inp = self.feat2tensor(feat)
      los, reploss_out, mets = repl_loss(
          last, term, rew, boot,
          self.val(inp, 2),
          self.slowval(inp, 2),
          self.valnorm,
          update=training,
          horizon=self.config.horizon,
          **self.config.repl_loss)
      losses.update(los)
      metrics.update(prefix_fn(mets, 'reploss'))

    assert set(losses.keys()) == set(self.scales.keys()), (
        sorted(losses.keys()), sorted(self.scales.keys()))
    metrics.update({f'loss/{k}': v.mean() for k, v in losses.items()})

    # Keep coefficients, raw losses, and weighted contributions distinct in
    # installation-smoke logs. Disabled branches are not executed and report
    # an exact zero contribution rather than a fabricated raw loss.
    rec_lambda = float(self.scales.get('htp_rec', 0.0))
    pdyn_lambda = float(self.scales.get('htp_pdyn', 0.0))
    rec_raw = losses['htp_rec'].mean() if 'htp_rec' in losses else jnp.array(0.0)
    pdyn_raw = losses['htp_pdyn'].mean() if 'htp_pdyn' in losses else jnp.array(0.0)
    rec_weighted = rec_lambda * rec_raw
    pdyn_weighted = pdyn_lambda * pdyn_raw
    metrics.update({
        'htp/lambda_rec': jnp.asarray(rec_lambda),
        'htp/raw_rec_loss': rec_raw,
        'htp/weighted_rec_loss': rec_weighted,
        'htp/rec_branch_executed': jnp.asarray('htp_rec' in losses),
        'htp/lambda_pdyn': jnp.asarray(pdyn_lambda),
        'htp/raw_pdyn_loss': pdyn_raw,
        'htp/weighted_pdyn_loss': pdyn_weighted,
        'htp/pdyn_branch_executed': jnp.asarray('htp_pdyn' in losses),
        'htp/weighted_total': rec_weighted + pdyn_weighted,
    })
    loss = sum([v.mean() * self.scales[k] for k, v in losses.items()])

    carry = (enc_carry, dyn_carry, dec_carry)
    entries = (enc_entries, dyn_entries, dec_entries)
    outs = {'tokens': tokens, 'repfeat': repfeat, 'losses': losses}
    return loss, (carry, entries, outs, metrics)

  def report(self, carry, data):
    if not self.config.report:
      return carry, {}

    carry, obs, prevact, _ = self._apply_replay_context(carry, data)
    (enc_carry, dyn_carry, dec_carry) = carry
    B, T = obs['is_first'].shape
    RB = min(6, B)
    metrics = {}

    _, (new_carry, entries, outs, mets) = self.loss(
        carry, obs, prevact, training=False)
    mets.update(mets)

    if self.config.report_gradnorms:
      for key in self.scales:
        try:
          lossfn = lambda data, carry: self.loss(
              carry, obs, prevact, training=False)[1][2]['losses'][key].mean()
          grad = nj.grad(lossfn, self.modules)(data, carry)[-1]
          metrics[f'gradnorm/{key}'] = optax.global_norm(grad)
        except KeyError:
          print(f'Skipping gradnorm summary for missing loss: {key}')

    firsthalf = lambda xs: jax.tree.map(lambda x: x[:RB, :T // 2], xs)
    secondhalf = lambda xs: jax.tree.map(lambda x: x[:RB, T // 2:], xs)
    dyn_carry = jax.tree.map(lambda x: x[:RB], dyn_carry)
    dec_carry = jax.tree.map(lambda x: x[:RB], dec_carry)
    dyn_carry, _, obsfeat = self.dyn.observe(
        dyn_carry, firsthalf(outs['tokens']), firsthalf(prevact),
        firsthalf(obs['is_first']), training=False)
    _, imgfeat, _ = self.dyn.imagine(
        dyn_carry, secondhalf(prevact), length=T - T // 2, training=False)
    dec_carry, _, obsrecons = self.dec(
        dec_carry, obsfeat, firsthalf(obs['is_first']), training=False)
    dec_carry, _, imgrecons = self.dec(
        dec_carry, imgfeat, jnp.zeros_like(secondhalf(obs['is_first'])),
        training=False)

    for key in self.dec.imgkeys:
      assert obs[key].dtype == jnp.uint8
      true = obs[key][:RB]
      pred = jnp.concatenate([obsrecons[key].pred(), imgrecons[key].pred()], 1)
      pred = jnp.clip(pred * 255, 0, 255).astype(jnp.uint8)
      error = ((i32(pred) - i32(true) + 255) / 2).astype(np.uint8)
      video = jnp.concatenate([true, pred, error], 2)

      video = jnp.pad(video, [[0, 0], [0, 0], [2, 2], [2, 2], [0, 0]])
      mask = jnp.zeros(video.shape, bool).at[:, :, 2:-2, 2:-2, :].set(True)
      border = jnp.full((T, 3), jnp.array([0, 255, 0]), jnp.uint8)
      border = border.at[T // 2:].set(jnp.array([255, 0, 0], jnp.uint8))
      video = jnp.where(mask, video, border[None, :, None, None, :])
      video = jnp.concatenate([video, 0 * video[:, :10]], 1)

      B, T, H, W, C = video.shape
      grid = video.transpose((1, 2, 0, 3, 4)).reshape((T, H, B * W, C))
      metrics[f'openloop/{key}'] = grid

    carry = (*new_carry, {k: data[k][:, -1] for k in self.act_space})
    return carry, metrics

  def _apply_replay_context(self, carry, data):
    (enc_carry, dyn_carry, dec_carry, prevact) = carry
    carry = (enc_carry, dyn_carry, dec_carry)
    stepid = data['stepid']
    obs = {k: data[k] for k in self.obs_space}
    prepend = lambda x, y: jnp.concatenate([x[:, None], y[:, :-1]], 1)
    prevact = {k: prepend(prevact[k], data[k]) for k in self.act_space}
    if not self.config.replay_context:
      return carry, obs, prevact, stepid

    K = self.config.replay_context
    nested = elements.tree.nestdict(data)
    entries = [nested.get(k, {}) for k in ('enc', 'dyn', 'dec')]
    lhs = lambda xs: jax.tree.map(lambda x: x[:, :K], xs)
    rhs = lambda xs: jax.tree.map(lambda x: x[:, K:], xs)
    rep_carry = (
        self.enc.truncate(lhs(entries[0]), enc_carry),
        self.dyn.truncate(lhs(entries[1]), dyn_carry),
        self.dec.truncate(lhs(entries[2]), dec_carry))
    rep_obs = {k: rhs(data[k]) for k in self.obs_space}
    rep_prevact = {k: data[k][:, K - 1: -1] for k in self.act_space}
    rep_stepid = rhs(stepid)

    first_chunk = (data['consec'][:, 0] == 0)
    carry, obs, prevact, stepid = jax.tree.map(
        lambda normal, replay: nn.where(first_chunk, replay, normal),
        (carry, rhs(obs), rhs(prevact), rhs(stepid)),
        (rep_carry, rep_obs, rep_prevact, rep_stepid))
    return carry, obs, prevact, stepid

  def _make_opt(
      self,
      lr: float = 4e-5,
      agc: float = 0.3,
      eps: float = 1e-20,
      beta1: float = 0.9,
      beta2: float = 0.999,
      momentum: bool = True,
      nesterov: bool = False,
      wd: float = 0.0,
      wdregex: str = r'/kernel$',
      schedule: str = 'const',
      warmup: int = 1000,
      anneal: int = 0,
  ):
    chain = []
    chain.append(embodied.jax.opt.clip_by_agc(agc))
    chain.append(embodied.jax.opt.scale_by_rms(beta2, eps))
    chain.append(embodied.jax.opt.scale_by_momentum(beta1, nesterov))
    if wd:
      assert not wdregex[0].isnumeric(), wdregex
      pattern = re.compile(wdregex)
      wdmask = lambda params: {k: bool(pattern.search(k)) for k in params}
      chain.append(optax.add_decayed_weights(wd, wdmask))
    assert anneal > 0 or schedule == 'const'
    if schedule == 'const':
      sched = optax.constant_schedule(lr)
    elif schedule == 'linear':
      sched = optax.linear_schedule(lr, 0.1 * lr, anneal - warmup)
    elif schedule == 'cosine':
      sched = optax.cosine_decay_schedule(lr, anneal - warmup, 0.1 * lr)
    else:
      raise NotImplementedError(schedule)
    if warmup:
      ramp = optax.linear_schedule(0.0, lr, warmup)
      sched = optax.join_schedules([ramp, sched], [warmup])
    chain.append(optax.scale_by_learning_rate(sched))
    return optax.chain(*chain)


def imag_loss(
    act, rew, con,
    policy, value, slowvalue,
    retnorm, valnorm, advnorm,
    update,
    contdisc=True,
    slowtar=True,
    horizon=333,
    lam=0.95,
    actent=3e-4,
    slowreg=1.0,
):
  losses = {}
  metrics = {}

  voffset, vscale = valnorm.stats()
  val = value.pred() * vscale + voffset
  slowval = slowvalue.pred() * vscale + voffset
  tarval = slowval if slowtar else val
  disc = 1 if contdisc else 1 - 1 / horizon
  weight = jnp.cumprod(disc * con, 1) / disc
  last = jnp.zeros_like(con)
  term = 1 - con
  ret = lambda_return(last, term, rew, tarval, tarval, disc, lam)

  roffset, rscale = retnorm(ret, update)
  adv = (ret - tarval[:, :-1]) / rscale
  aoffset, ascale = advnorm(adv, update)
  adv_normed = (adv - aoffset) / ascale
  logpi = sum([v.logp(sg(act[k]))[:, :-1] for k, v in policy.items()])
  ents = {k: v.entropy()[:, :-1] for k, v in policy.items()}
  policy_loss = sg(weight[:, :-1]) * -(
      logpi * sg(adv_normed) + actent * sum(ents.values()))
  losses['policy'] = policy_loss

  voffset, vscale = valnorm(ret, update)
  tar_normed = (ret - voffset) / vscale
  tar_padded = jnp.concatenate([tar_normed, 0 * tar_normed[:, -1:]], 1)
  losses['value'] = sg(weight[:, :-1]) * (
      value.loss(sg(tar_padded)) +
      slowreg * value.loss(sg(slowvalue.pred())))[:, :-1]

  ret_normed = (ret - roffset) / rscale
  metrics['adv'] = adv.mean()
  metrics['adv_std'] = adv.std()
  metrics['adv_mag'] = jnp.abs(adv).mean()
  metrics['rew'] = rew.mean()
  metrics['con'] = con.mean()
  metrics['ret'] = ret_normed.mean()
  metrics['val'] = val.mean()
  metrics['tar'] = tar_normed.mean()
  metrics['weight'] = weight.mean()
  metrics['slowval'] = slowval.mean()
  metrics['ret_min'] = ret_normed.min()
  metrics['ret_max'] = ret_normed.max()
  metrics['ret_rate'] = (jnp.abs(ret_normed) >= 1.0).mean()
  for k in act:
    metrics[f'ent/{k}'] = ents[k].mean()
    if hasattr(policy[k], 'minent'):
      lo, hi = policy[k].minent, policy[k].maxent
      metrics[f'rand/{k}'] = (ents[k].mean() - lo) / (hi - lo)

  outs = {}
  outs['ret'] = ret
  return losses, outs, metrics


def repl_loss(
    last, term, rew, boot,
    value, slowvalue, valnorm,
    update=True,
    slowreg=1.0,
    slowtar=True,
    horizon=333,
    lam=0.95,
):
  losses = {}

  voffset, vscale = valnorm.stats()
  val = value.pred() * vscale + voffset
  slowval = slowvalue.pred() * vscale + voffset
  tarval = slowval if slowtar else val
  disc = 1 - 1 / horizon
  weight = f32(~last)
  ret = lambda_return(last, term, rew, tarval, boot, disc, lam)

  voffset, vscale = valnorm(ret, update)
  ret_normed = (ret - voffset) / vscale
  ret_padded = jnp.concatenate([ret_normed, 0 * ret_normed[:, -1:]], 1)
  losses['repval'] = weight[:, :-1] * (
      value.loss(sg(ret_padded)) +
      slowreg * value.loss(sg(slowvalue.pred())))[:, :-1]

  outs = {}
  outs['ret'] = ret
  metrics = {}

  return losses, outs, metrics


def lambda_return(last, term, rew, val, boot, disc, lam):
  chex.assert_equal_shape((last, term, rew, val, boot))
  rets = [boot[:, -1]]
  live = (1 - f32(term))[:, 1:] * disc
  cont = (1 - f32(last))[:, 1:] * lam
  interm = rew[:, 1:] + (1 - cont) * live * boot[:, 1:]
  for t in reversed(range(live.shape[1])):
    rets.append(interm[:, t] + live[:, t] * cont[:, t] * rets[-1])
  return jnp.stack(list(reversed(rets))[:-1], 1)
