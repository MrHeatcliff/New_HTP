"""Train/evaluate the remaining Atari games with the frozen Harmony method."""
import concurrent.futures
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import time

from .config import ATARI100K_GAMES
from .h200_suite import atomic, slots
from .reborn_experiment import command
from .reborn_checkpoint_eval import worker as evaluate
from .reborn_hypothesis_suite import run_stage

EXISTING=('boxing','up_n_down','frostbite','road_runner')
GAMES=tuple(g for g in ATARI100K_GAMES if g not in EXISTING)


def main(root):
  assert os.environ.get('SLURM_JOB_ID'), 'Slurm required'
  root=Path(root).resolve();source=root/'source'
  assert len(GAMES)==22 and len(set(GAMES)|set(EXISTING))==26
  devices=[]
  for d in os.environ['CUDA_VISIBLE_DEVICES'].split(','):
    uuid,name=subprocess.check_output(['nvidia-smi','-i',d,'--query-gpu=uuid,name',
        '--format=csv,noheader'],text=True).strip().split(', ')
    assert 'H200' in name
    devices.append(uuid)
  assigned=slots(sorted(os.sched_getaffinity(0)),devices)
  atomic(root/'manifest.json',dict(job=os.environ['SLURM_JOB_ID'],games=GAMES,excluded=EXISTING,
      training_seed=0,evaluation_seed=0,actions=100000,arm='harmony',slots=assigned,
      source=str(source),started=time.time(),eval_schedule=[10]*9+[100]))
  atomic(root/'status.json',dict(status='TESTING'))
  run_stage(root,'tests',[sys.executable,'-m','pytest','tests/test_reborn.py',
      'tests/test_h200_suite.py','-q'],assigned[0],source)
  jobs=queue.Queue()
  for game in GAMES:jobs.put(game)
  atomic(root/'status.json',dict(status='RUNNING',games=GAMES))
  def work(slot):
    results=[]
    while True:
      try:game=jobs.get_nowait()
      except queue.Empty:break
      out=root/game;out.mkdir()
      try:
        run_stage(out,'train',command(game,out/'full','harmony')+[
            '--run.steps','100000','--run.exact_env_action_budget','True',
            '--run.action_milestones',*map(str,range(10000,100001,10000))],slot,source)
        atomic(out/'stage.json',dict(status='RUNNING',stage='checkpoint_eval'))
        evaluate(root,root/'evaluation',game,slot,'harmony')
        atomic(out/'stage.json',dict(status='COMPLETE'))
        results.append(dict(game=game,status='COMPLETE'))
      except BaseException as exc:
        atomic(out/'stage.json',dict(status='FAILED',error=str(exc)))
        results.append(dict(game=game,status='FAILED',error=str(exc)))
        print(f'FAILED {game}: {exc}',flush=True)
      finally:jobs.task_done()
    return results
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    futures=[pool.submit(work,s) for s in assigned]
    results=[r for f in futures for r in f.result()]
  complete=len(results)==22 and all(r['status']=='COMPLETE' for r in results)
  atomic(root/'status.json',dict(status='COMPLETE' if complete else 'FAILED',results=results,
      completed=sum(r['status']=='COMPLETE' for r in results),finished=time.time()))
  if not complete:raise RuntimeError('Some games failed; inspect per-game stage.json')


if __name__=='__main__':main(sys.argv[1])
