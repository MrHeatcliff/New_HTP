"""Summarize existing component audit in Slurm, retaining episode uncertainty."""
import json
import os
from pathlib import Path
import sys
import numpy as np

GAMES = ('boxing','up_n_down','frostbite','road_runner')
ARMS = ('image_uniform','image_pyramid','image_soft')

def summarize(root, output):
  if not os.environ.get('SLURM_JOB_ID'): raise RuntimeError('Slurm only')
  root, output = Path(root), Path(output)
  rng = np.random.default_rng(260911)
  result = {}
  lines = ['# Component audit 3526: quantitative summary', '',
      'Equal episode means unless labeled event-weighted. CIs resample the ten held-out episodes (5000 draws); conditional on seed-1 checkpoints. No training-seed uncertainty.', '',
      '| Game / arm | Predictor/copy B1 | Action-roll/true B1 | Reward MAE | Nonzero reward MAE | Rollout reward MAE | B1/B5 actor KL (roll) | Terminal events |',
      '|---|---:|---:|---:|---:|---:|---|---:|']
  for game in GAMES:
    result[game] = {}
    for arm in ARMS:
      raw = json.loads((root/game/f'{arm}.json').read_text())
      if raw['status'] != 'COMPLETE' or len(raw['episodes']) != 10: raise ValueError((game,arm))
      ep = list(raw['episodes'].values())
      true, copy, rolled = [np.array([e['prediction'][key] for e in ep]) for key in ('true','copy','time_roll')]
      def ci(values):
        means = values[rng.integers(len(values),size=(5000,len(values)))].mean(1)
        return {'mean':float(values.mean()),'ci95':np.quantile(means,[.025,.975]).tolist()}
      def weighted(stratum):
        pairs = [(e['posterior'][stratum]['count'],e['posterior'][stratum]['reward_mae']) for e in ep]
        count = sum(n for n,_ in pairs)
        return sum(n*v for n,v in pairs if n)/count if count else None
      row = {'predictor_over_copy':(true.mean(0)/copy.mean(0)).tolist(),
          'action_roll_over_true':(rolled.mean(0)/true.mean(0)).tolist(),
          'b1_copy_minus_predictor':ci(copy[:,0]-true[:,0]),
          'b1_roll_minus_true':ci(rolled[:,0]-true[:,0]),
          'posterior_reward_mae':float(np.mean([e['posterior']['reward_mae'] for e in ep])),
          'nonzero_reward_mae_event_weighted':weighted('nonzero_reward'),
          'rollout_reward_mae':float(np.mean([e['rollout']['true']['heads']['reward_mae'] for e in ep])),
          'rollout_zero_reward_mae':float(np.mean([e['rollout']['true']['heads']['zero_reward_baseline_mae'] for e in ep])),
          'actor_kl_time_roll':[float(np.mean([e['interventions'][f'block{i}_time_roll']['actor_kl'] for e in ep])) for i in range(1,6)],
          'terminal_events':sum(e['posterior']['terminal']['count'] for e in ep),
          'base_posterior_mae':float(np.mean([e['base_posterior_mae'] for e in ep])),
          'rollout_image_mae_64':float(np.mean([e['rollout']['true']['image_mae_by_step'][-1] for e in ep])),
          'value_residual':float(np.mean([e['source_policy_one_step_value_residual_mae'] for e in ep]))}
      result[game][arm] = row
      lines.append(f'| {game}/{arm} | {row["predictor_over_copy"][0]:.3f} | {row["action_roll_over_true"][0]:.3f} | {row["posterior_reward_mae"]:.3f} | {row["nonzero_reward_mae_event_weighted"]} | {row["rollout_reward_mae"]:.3f} | {row["actor_kl_time_roll"][0]:.3f}/{row["actor_kl_time_roll"][4]:.3f} | {row["terminal_events"]} |')
  lines += ['', 'Lower predictor/copy indicates better error than copy; action-roll/true above one indicates sensitivity. Neither proves stable semantics. Block widths are 128/128/256/512/1024: B1-vs-B5 KL is confounded by intervention size. Posterior and rollout reward errors use different windows in this first audit. Zero terminal counts preclude terminal calibration. Value residuals are off-policy, not on-policy accuracy.', '',
      'Spatial seed 2: soft loses to pyramid in all four games. No soft-target promotion. Subsequent matched-window, matched-RNG and equal-width controls are required before attributing failures.']
  output.with_suffix('.json').write_text(json.dumps(result,indent=2,allow_nan=False))
  output.with_suffix('.md').write_text('\n'.join(lines)+'\n')
  print('\n'.join(lines),flush=True)

if __name__ == '__main__': summarize(*sys.argv[1:])
