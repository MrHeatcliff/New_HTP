"""Seed replication scheduler; model and evaluator protocol remain frozen."""
import concurrent.futures
import json
import math
import os
from pathlib import Path
import queue
import subprocess
import sys
import time

from .config import ATARI100K_GAMES
from .h200_suite import atomic, slots
from .reborn_experiment import command
from .reborn_checkpoint_eval import digest
from .reborn_hypothesis_suite import run_stage


def train_command(game, destination, seed):
  cmd = command(game, destination, 'harmony')
  cmd[cmd.index('--seed')+1] = str(seed)
  return cmd + ['--run.steps', '100000', '--run.exact_env_action_budget', 'True',
                '--run.action_milestones', *map(str, range(10000, 100001, 10000))]


def evaluate(source, out, game, seed, slot):
  output = out/'evaluation'; output.mkdir(exist_ok=True)
  # Match seed-0 isolated evaluator: evaluation RNG seed stays 0 for every policy.
  env = dict(os.environ, CUDA_VISIBLE_DEVICES=slot['gpu'], OMP_NUM_THREADS='8',
      OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONPATH=str(source),
      XLA_PYTHON_CLIENT_PREALLOCATE='false', PAPER_TRAINING_SEED=str(seed),
      PAPER_EVALUATION_SEED='0', PAPER_METHOD='Reborn', WANDB_MODE='disabled')
  rows = []
  for step in range(10000, 100001, 10000):
    checkpoint = out/'full/ckpt'/f'env_action_steps_{step:09d}'
    assert (checkpoint/'agent.pkl').is_file(), checkpoint
    before = digest(checkpoint)
    destination = output/f'{step:06d}'
    episodes = 100 if step == 100000 else 10
    cmd = command(game, destination, 'harmony') + [
        '--script', 'eval_only', '--run.from_checkpoint', str(checkpoint),
        '--run.envs', '1', '--run.eval_eps', str(episodes), '--run.steps', '1000000000']
    atomic(output/'progress.json', dict(status='RUNNING', checkpoint=step, completed=rows))
    atomic(output/f'request_{step}.json', dict(command=cmd, hash=before,
        episodes=episodes, training_seed=seed, evaluation_seed=0))
    print(f'EVAL seed={seed} game={game} checkpoint={step}', flush=True)
    with (output/f'eval_{step}.log').open('w') as stream:
      subprocess.run(['taskset', '-c', ','.join(map(str, slot['cpus'])), *cmd],
          cwd=source, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
    scores = [json.loads(line)['episode/score'] for line in
              (destination/'scores.jsonl').read_text().splitlines()]
    assert len(scores) == episodes and all(map(math.isfinite, scores))
    assert before == digest(checkpoint), 'Checkpoint modified during evaluation'
    rows.append(dict(game=game, checkpoint=step, episodes=episodes, returns=scores,
        mean=sum(scores)/len(scores), checkpoint_hash=before,
        training_seed=seed, evaluation_seed=0))
    atomic(output/'summary.json', rows)
  atomic(output/'progress.json', dict(status='COMPLETE', completed=rows))


def main(root):
  assert os.environ.get('SLURM_JOB_ID'), 'Slurm required'
  root = Path(root).resolve(); source = root/'source'
  devices = []
  for device in os.environ['CUDA_VISIBLE_DEVICES'].split(','):
    uuid, name = subprocess.check_output(['nvidia-smi', '-i', device,
        '--query-gpu=uuid,name', '--format=csv,noheader'], text=True).strip().split(', ')
    assert 'H200' in name
    devices.append(uuid)
  assigned = slots(sorted(os.sched_getaffinity(0)), devices)
  jobs = queue.Queue()
  for seed in range(1, 5):
    for game in ATARI100K_GAMES:
      jobs.put((seed, game))
  assert jobs.qsize() == 104
  for seed in range(1, 5):
    cmd = train_command('alien', root/'preflight', seed)
    assert cmd[cmd.index('--seed')+1] == str(seed)
    assert cmd[cmd.index('--agent.reborn.harmony')+1] == 'True'
  atomic(root/'manifest.json', dict(job=os.environ['SLURM_JOB_ID'], slots=assigned,
      training_seeds=[1,2,3,4], evaluation_seed=0, games=ATARI100K_GAMES,
      runs=104, actions=100000, eval_schedule=[10]*9+[100], started=time.time()))
  atomic(root/'status.json', dict(status='TESTING'))
  run_stage(root, 'tests', [sys.executable, '-m', 'pytest', 'tests/test_reborn.py',
      'tests/test_h200_suite.py', '-q'], assigned[0], source)
  atomic(root/'status.json', dict(status='RUNNING'))
  def work(slot):
    results = []
    while True:
      try: seed, game = jobs.get_nowait()
      except queue.Empty: break
      out = root/f'seed_{seed}'/game; out.mkdir(parents=True, exist_ok=True)
      started = time.time()
      try:
        # Same training environment as seed 0; only configured training seed changes.
        run_stage(out, 'train', train_command(game, out/'full', seed), slot, source)
        atomic(out/'stage.json', dict(status='RUNNING', stage='evaluation', seed=seed))
        evaluate(source, out, game, seed, slot)
        result = dict(seed=seed, game=game, status='COMPLETE', seconds=time.time()-started)
      except Exception as exc:
        result = dict(seed=seed, game=game, status='FAILED', error=str(exc))
        print(f'FAILED {result}', flush=True)
      atomic(out/'stage.json', result)
      results.append(result); jobs.task_done()
      print(f'END {result}', flush=True)
    return results
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = [r for future in [pool.submit(work, s) for s in assigned] for r in future.result()]
  complete = len(results) == 104 and all(r['status'] == 'COMPLETE' for r in results)
  atomic(root/'status.json', dict(status='COMPLETE' if complete else 'FAILED',
      results=results, completed=sum(r['status']=='COMPLETE' for r in results), finished=time.time()))
  if not complete: raise RuntimeError('Inspect failed per-game stage.json')


if __name__ == '__main__':
  main(sys.argv[1])
