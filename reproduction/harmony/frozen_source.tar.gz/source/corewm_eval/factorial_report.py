"""Paired episode-bootstrap summary for completed constrained factorial."""
import json
import os
from pathlib import Path
import sys
import numpy as np

GAMES=('boxing','up_n_down','frostbite','road_runner')
ARMS=('flat','rec_only','pdyn_only','full')

def main(root,out):
  if not os.environ.get('SLURM_JOB_ID'): raise RuntimeError('Slurm required')
  root,out=Path(root),Path(out); rng=np.random.default_rng(3669); report={}
  for game in GAMES:
    raw=json.loads((root/game/'results.json').read_text())
    scores={a:np.asarray(raw[a]['scores'],np.float64) for a in ARMS}
    if any(len(x)!=20 for x in scores.values()): raise ValueError(game)
    sample={a:x[rng.integers(20,size=(20000,20))].mean(1) for a,x in scores.items()}
    effects={
      'rec_without_prediction':sample['rec_only']-sample['flat'],
      'rec_with_prediction':sample['full']-sample['pdyn_only'],
      'prediction_without_rec':sample['pdyn_only']-sample['flat'],
      'prediction_with_rec':sample['full']-sample['rec_only'],
      'interaction':sample['full']-sample['rec_only']-sample['pdyn_only']+sample['flat']}
    reps={}
    for arm in ARMS:
      r=json.loads((root/game/f'{arm}_representation.json').read_text())
      reps[arm]={'rank_b1':r['blocks'][0]['effective_rank'],'rank_b2':r['blocks'][1]['effective_rank'],
        'cka_b1_b2':r['cka'],'r2_b1_h16':r['horizons']['16']['block1']['r2'],
        'r2_b1_h64':r['horizons']['64']['block1']['r2'],'displacement_b1_h64':r['blocks'][0]['whitened_change']['64'],
        'dead_b1':r['dead_coordinates']}
    point={'rec_without_prediction':raw['rec_only']['mean']-raw['flat']['mean'],
      'rec_with_prediction':raw['full']['mean']-raw['pdyn_only']['mean'],
      'prediction_without_rec':raw['pdyn_only']['mean']-raw['flat']['mean'],
      'prediction_with_rec':raw['full']['mean']-raw['rec_only']['mean'],
      'interaction':raw['full']['mean']-raw['rec_only']['mean']-raw['pdyn_only']['mean']+raw['flat']['mean']}
    report[game]={'means':{a:raw[a]['mean'] for a in ARMS},'effects':{k:{'estimate':point[k],
      'episode_bootstrap_ci95':np.quantile(v,[.025,.975]).tolist()} for k,v in effects.items()},'representation':reps}
  out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
  print(json.dumps(report,indent=2,allow_nan=False))

if __name__=='__main__': main(*sys.argv[1:])
