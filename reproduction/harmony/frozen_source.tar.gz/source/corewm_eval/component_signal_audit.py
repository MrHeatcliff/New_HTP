"""Frozen-checkpoint, common-trajectory component audit. Slurm only."""
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import sys

import jax
import jax.numpy as jnp
import ninjax as nj
import numpy as np

from dreamerv3.htp import flatten_action_dict
from .extraction import _extract_impl, _flat_to_feat, evaluation_seed
from .four_game_representation import agent_for
from .h200_suite import atomic, slots
from .paper_pipeline import _padded_batch

GAMES = ('boxing', 'up_n_down', 'frostbite', 'road_runner')
ARMS = ('image_uniform', 'image_pyramid', 'image_soft')


def heads(model, z):
  policy = model.pol(z, 2)['action']
  probabilities = jnp.stack([policy.prob(jnp.full(z.shape[:2], a, jnp.int32))
      for a in range(int(model.act_space['action'].high))], -1)
  offset, scale = model.valnorm.stats()
  return dict(reward=model.rew(z, 2).pred(), con=model.con(z, 2).prob(1),
              value=model.val(z, 2).pred() * scale + offset,
              policy=probabilities, entropy=policy.entropy())


def measure(model, spec, obs, prevact, actions):
  extracted = _extract_impl(model, obs, prevact, spec, decode=False)
  h, z = extracted['h'], extracted['z']
  reset = obs['is_first']
  outputs = {'heads': heads(model, z), 'interventions': {}}
  for level, (lo, hi) in enumerate(zip((0, *spec.prefix_dims[:-1]), spec.prefix_dims)):
    for intervention in ('zero', 'time_roll'):
      replacement = (jnp.zeros_like(z[..., lo:hi]) if intervention == 'zero'
                     else jnp.roll(z[..., lo:hi], 17, axis=1))
      masked = z.at[..., lo:hi].set(replacement)
      outputs['interventions'][f'block{level+1}_{intervention}'] = heads(model, masked)
  if os.environ.get('HTP_MATCHED_AUDIT') == '1':
    for lo in range(0, z.shape[-1], 128):
      changed = z.at[...,lo:lo+128].set(jnp.roll(z[...,lo:lo+128],17,axis=1))
      outputs['interventions'][f'chunk{lo//128+1}_time_roll'] = heads(model,changed)
  _, _, decoded = model.dec(model.dec.initial(1), _flat_to_feat(h, spec), reset, training=False)
  outputs['base_mae'] = jnp.abs(decoded['image'].pred() - obs['image'].astype(jnp.float32)/255).mean((-3,-2,-1))
  image_target = obs['image'].astype(jnp.float32).reshape((*z.shape[:2], -1))/255
  _, rec = model.htp_recon(z, image_target, reset=reset)
  outputs['reconstruction_target_mse'] = jnp.stack([x.mean() for x in rec])
  slow = model.slow_htp_proj(h)
  flat = flatten_action_dict({'action': actions}, model.act_space)
  outputs['prediction'] = {}
  for condition, action_input in [('true', flat), ('time_roll', jnp.roll(flat,17,axis=1)), ('zero', jnp.zeros_like(flat))]:
    _, levels = model.htp_pdyn(z, slow, action_input, reset=reset)
    outputs['prediction'][condition] = jnp.stack([row['err_mean'] for row in levels])
  outputs['prediction']['copy'] = jnp.stack([
      jnp.square(slow[:, :-lag, :dim] - slow[:, lag:, :dim]).mean()
      for dim, lag in zip(model.htp_pdyn.dims, model.htp_pdyn.strides)])
  outputs['prediction']['target_variance'] = jnp.stack([
      slow[:, lag:, :dim].astype(jnp.float32).var((0,1)).mean()
      for dim, lag in zip(model.htp_pdyn.dims, model.htp_pdyn.strides)])
  # The source episode itself never crosses a reset. No synthetic padded pairs.
  start, horizon = 16, min(64, z.shape[1] - 17)
  state = jax.tree.map(lambda x: x[:, start], extracted['posterior'])
  if os.environ.get('HTP_MATCHED_AUDIT') == '1':
    outputs['rollout_state'] = state
    return outputs
  outputs['rollout'] = {}
  for condition, acts in [('true', actions[:, start:start+horizon]),
                          ('time_roll', jnp.roll(actions[:, start:start+horizon], 7, axis=1))]:
    _, feat, _ = model.dyn.imagine(state, {'action': acts}, horizon, training=False)
    imagined = model.feat2tensor(feat)
    _, _, decoded = model.dec(model.dec.initial(1), feat, jnp.zeros((1,horizon),bool), training=False)
    outputs['rollout'][condition] = dict(heads=heads(model, imagined),
        image_mae=jnp.abs(decoded['image'].pred()-obs['image'][:,start+1:start+horizon+1].astype(jnp.float32)/255).mean((-3,-2,-1)))
  return outputs


def controlled_rollout(model, state, actions, images):
  horizon = actions.shape[1]
  _, feat, _ = model.dyn.imagine(state, {'action':actions}, horizon, training=False)
  _, _, decoded = model.dec(model.dec.initial(1),feat,jnp.zeros((1,horizon),bool),training=False)
  return dict(heads=heads(model,model.feat2tensor(feat)),
      image_mae=jnp.abs(decoded['image'].pred()-images.astype(jnp.float32)/255).mean((-3,-2,-1)))


def head_errors(head, reward, terminal, discount):
  reward, terminal = np.asarray(reward), np.asarray(terminal, bool)
  pred = np.asarray(head['reward']).reshape(-1)
  survival = np.asarray(head['con']).reshape(-1)
  target = (~terminal).astype(float) * discount
  result = {'count': len(reward), 'reward_mae': float(np.abs(pred-reward).mean()),
      'zero_reward_baseline_mae': float(np.abs(reward).mean()),
      'continuation_brier_training_target': float(np.square(survival-target).mean()),
      'actor_entropy': float(np.asarray(head['entropy']).mean())}
  for name, mask in [('nonzero_reward',reward!=0), ('zero_reward',reward==0), ('terminal',terminal), ('nonterminal',~terminal)]:
    result[name] = {'count': int(mask.sum()),
        'reward_mae': float(np.abs(pred[mask]-reward[mask]).mean()) if mask.any() else None,
        'continuation_brier': float(np.square(survival[mask]-target[mask]).mean()) if mask.any() else None}
  return result


def intervention_metrics(reference, changed):
  p, q = [np.clip(np.asarray(x['policy']),1e-12,1) for x in (reference,changed)]
  return {'actor_kl': float((p*np.log(p/q)).sum(-1).mean()),
      'greedy_action_change': float((p.argmax(-1)!=q.argmax(-1)).mean()),
      'reward_change': float(np.abs(reference['reward']-changed['reward']).mean()),
      'value_change': float(np.abs(reference['value']-changed['value']).mean())}


def audit_checkpoint(source, dataset, output):
  config, agent, spec = agent_for(source, source/'ckpt/env_action_steps_000100000')
  params = agent.save()['params']
  pure = nj.pure(lambda obs, prevact, actions: measure(agent.model, spec, obs, prevact, actions))
  split = json.loads((dataset/'split.json').read_text())
  discount = 1 - 1/config.agent.horizon if config.agent.contdisc else 1.
  rows = {}
  for eid in sorted(split['test']):
    with np.load(dataset/f'episode_{eid:02d}.npz') as data: ep = dict(data)
    length = len(ep['action'])
    if length < 66: raise ValueError('Insufficient diagnostic horizon')
    obs, prevact, _ = _padded_batch([ep], length)
    with jax._src.config.explicit_device_put_scope():
      returned, result = pure(params, obs, prevact, ep['action'][None],
          seed=evaluation_seed(0,eid), create=False, modify=True, ignore=True)
    with jax._src.config.explicit_device_get_scope(): result = jax.tree.map(np.asarray,result)
    if os.environ.get('HTP_MATCHED_AUDIT') == '1':
      rollout_fn = nj.pure(lambda state, acts, imgs: controlled_rollout(agent.model,state,acts,imgs))
      horizon = min(64,length-17)
      result['rollout'] = {}
      for condition in ('true','time_roll','true_repeat'):
        acts = ep['action'][None,16:16+horizon]
        if condition == 'time_roll': acts = np.roll(acts,7,axis=1)
        with jax._src.config.explicit_device_put_scope():
          _, roll = rollout_fn(params,result['rollout_state'],acts,ep['observation'][None,17:17+horizon],
              seed=evaluation_seed(0,eid,16,1),create=False,modify=True,ignore=True)
        with jax._src.config.explicit_device_get_scope(): result['rollout'][condition] = jax.tree.map(np.asarray,roll)
      for a,b in zip(jax.tree.leaves(result['rollout']['true']),jax.tree.leaves(result['rollout']['true_repeat'])):
        np.testing.assert_array_equal(a,b)
    if set(returned) != set(params): raise AssertionError('Checkpoint parameter keys changed')
    head = result['heads']
    row = {'posterior': head_errors(head,ep['reward'],ep['is_terminal'],discount),
        'base_posterior_mae': float(result['base_mae'].mean()),
        'reconstruction_target_mse': result['reconstruction_target_mse'].tolist(),
        'prediction': {k:v.tolist() for k,v in result['prediction'].items()},
        'interventions': {k:intervention_metrics(head,v) for k,v in result['interventions'].items()},
        'rollout': {}}
    if os.environ.get('HTP_MATCHED_AUDIT') == '1':
      n = min(64,length-17)
      window = {k:v[:,17:17+n] for k,v in head.items()}
      row['posterior_matched_rollout_window'] = head_errors(window,ep['reward'][17:17+n],ep['is_terminal'][17:17+n],discount)
      row['paired_rng_repeat_exact'] = True
    gamma = 1 - 1/config.agent.horizon
    value = head['value'].reshape(-1)
    td = value[:-1] - (ep['reward'][1:] + gamma*(~ep['is_terminal'][1:])*value[1:])
    row['source_policy_one_step_value_residual_mae'] = float(np.abs(td).mean())
    for condition, roll in result['rollout'].items():
      n = roll['image_mae'].shape[1]
      row['rollout'][condition] = {'image_mae_by_step': roll['image_mae'][0].tolist(),
          'heads': head_errors(roll['heads'],ep['reward'][17:17+n],ep['is_terminal'][17:17+n],discount)}
    rows[str(eid)] = row
    atomic(output, {'source':str(source),'episodes':rows,'status':'RUNNING'})
    print(f'EPISODE {source.name} {eid}',flush=True)
  atomic(output, {'source':str(source),'episodes':rows,'status':'COMPLETE',
      'limitations':['Source-policy early clips, off-policy for evaluated actors.',
      'Value residual is off-policy consistency, not on-policy value calibration.',
      'Block zero/time-roll is an out-of-distribution reliance test, not training ablation.',
      'Action controls are observational sensitivity, not action intervention ground truth.',
      ('Rollout control uses matched RNG with an exact-repeat check.' if os.environ.get('HTP_MATCHED_AUDIT') == '1' else 'Rollout action controls use different stochastic draws; replicate RNG before causal attribution.'),
      'Reconstruction losses use different targets across arms; not directly comparable.',
      'No gradient-conflict measurement or constrained factorial in this audit.']})


def worker(game, root):
  repo = Path(os.environ['HTP_RESEARCH_REPO'])
  source = repo/'production_runs/spatial_refine_vMknLzBP'/game
  out = root/game; out.mkdir()
  for arm in ARMS: audit_checkpoint(source/arm, source/'fixed_clips', out/f'{arm}.json')


def main(root):
  if not os.environ.get('SLURM_JOB_ID'): raise RuntimeError('Slurm required')
  root = Path(root)
  devices = []
  for device in os.environ['CUDA_VISIBLE_DEVICES'].split(','):
    uuid, name = subprocess.check_output(['nvidia-smi','-i',device,'--query-gpu=uuid,name','--format=csv,noheader'],text=True).strip().split(', ')
    if 'H200' not in name: raise RuntimeError(name)
    devices.append(uuid)
  assigned = slots(sorted(os.sched_getaffinity(0)),devices)
  atomic(root/'manifest.json',{'job':os.environ['SLURM_JOB_ID'],'slots':assigned,'games':GAMES,'arms':ARMS,'training_seed':1,'mode':'read-only common-trajectory audit'})
  atomic(root/'status.json',{'status':'RUNNING'})
  def launch(game, slot):
    env = dict(os.environ,CUDA_VISIBLE_DEVICES=slot['gpu'],OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',XLA_PYTHON_CLIENT_PREALLOCATE='false')
    with (root/f'{game}.log').open('w') as log:
      subprocess.run(['taskset','-c',','.join(map(str,slot['cpus'])),sys.executable,'-u','-m',__package__+'.component_signal_audit',str(root),game],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
      futures = [pool.submit(launch,g,s) for g,s in zip(GAMES,assigned)]
      for future in concurrent.futures.as_completed(futures): future.result()
    atomic(root/'status.json',{'status':'COMPLETE'})
  except BaseException as exc:
    atomic(root/'status.json',{'status':'FAILED','error':str(exc)}); raise


if __name__ == '__main__':
  if not os.environ.get('SLURM_JOB_ID'): raise RuntimeError('Slurm required')
  if len(sys.argv)==3: worker(sys.argv[2],Path(sys.argv[1]))
  else: main(sys.argv[1])
