"""Conditional episode bootstrap; execute inside the spatial Slurm job."""
import json
import os
from pathlib import Path
import sys
import numpy as np
from .persistence_research_report import control_comparison


def main(out, run='spatial_recon_YQ5FnA9w'):
  if not os.environ.get('SLURM_JOB_ID'): raise RuntimeError('Slurm required')
  root = Path(os.environ['HTP_RESEARCH_REPO']) / 'production_runs' / run
  rng = np.random.default_rng(260910)
  report = {}
  for game in ('boxing', 'up_n_down', 'frostbite', 'road_runner'):
    scores = json.loads((root/game/'results.json').read_text())
    reps = {arm: json.loads((root/game/f'{arm}_representation.json').read_text()) for arm in scores}
    report[game] = {'control_pyramid_minus_uniform': control_comparison(
        np.array(scores['image_uniform']['scores']), np.array(scores['image_pyramid']['scores']), rng),
        'representation': reps,
        'limitation': 'Episode bootstrap conditions on one trained seed; cannot establish seed robustness.'}
    if 'image_soft' in scores:
      for reference in ('image_pyramid', 'image_uniform'):
        report[game]['control_soft_minus_' + reference] = control_comparison(
            np.array(scores[reference]['scores']), np.array(scores['image_soft']['scores']), rng)
  Path(out).write_text(json.dumps(report, indent=2, allow_nan=False))
  for game, row in report.items(): print(game, row['control_pyramid_minus_uniform'], flush=True)


if __name__ == '__main__': main(*sys.argv[1:])
