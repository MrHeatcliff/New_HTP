"""Matched audit summary, numerical work restricted to Slurm."""
import json
import os
from pathlib import Path
import sys
import numpy as np

def main(root, output):
  if not os.environ.get('SLURM_JOB_ID'): raise RuntimeError('Slurm required')
  root, output = Path(root), Path(output)
  rng = np.random.default_rng(3668)
  rows = {}
  lines = ['# Matched audit 3668', '',
      'Seed-1 frozen checkpoints; ten common held-out episodes. Reward comparisons use exactly the same frames. Paired bootstrap uses 5000 episode resamples, not training seeds.', '',
      '| Game/arm | Posterior reward MAE | Imagined reward MAE | Imagined minus posterior (95% CI) | Action-roll image MAE minus true | B1 actor KL | Mean B5 128-D chunk KL |',
      '|---|---:|---:|---|---:|---:|---:|']
  for game in ('boxing','up_n_down','frostbite','road_runner'):
    rows[game] = {}
    for arm in ('image_uniform','image_pyramid','image_soft'):
      raw = json.loads((root/game/f'{arm}.json').read_text())
      ep = list(raw['episodes'].values())
      assert raw['status']=='COMPLETE' and len(ep)==10 and all(e['paired_rng_repeat_exact'] for e in ep)
      post = np.array([e['posterior_matched_rollout_window']['reward_mae'] for e in ep])
      imag = np.array([e['rollout']['true']['heads']['reward_mae'] for e in ep])
      delta = imag-post
      ci = np.quantile(delta[rng.integers(10,size=(5000,10))].mean(1),[.025,.975])
      chunks = np.array([[e['interventions'][f'chunk{i}_time_roll']['actor_kl'] for i in range(1,17)] for e in ep])
      action_gap = np.mean([np.mean(e['rollout']['time_roll']['image_mae_by_step'])-np.mean(e['rollout']['true']['image_mae_by_step']) for e in ep])
      row = {'posterior_mae':float(post.mean()),'imagined_mae':float(imag.mean()),'imagined_minus_posterior':float(delta.mean()),'difference_ci95':ci.tolist(),
          'action_roll_minus_true_image_mae':float(action_gap),'chunk_actor_kl':chunks.mean(0).tolist(),
          'b5_mean_chunk_kl':float(chunks[:,8:].mean()),'terminal_events':sum(e['posterior']['terminal']['count'] for e in ep)}
      rows[game][arm] = row
      lines.append(f'| {game}/{arm} | {post.mean():.3f} | {imag.mean():.3f} | {delta.mean():.3f} [{ci[0]:.3f}, {ci[1]:.3f}] | {action_gap:.5f} | {chunks[:,0].mean():.4f} | {chunks[:,8:].mean():.4f} |')
  lines += ['', 'Equal-width interventions remove the dimensionality confound, but their covariance and perturbation magnitudes still differ. KL measures reliance, not usefulness. Same-RNG action controls measure model sensitivity, not ground-truth counterfactual accuracy. No terminals means terminal calibration remains unmeasured. These image-reconstruction checkpoints are not the original latent-reconstruction 26-game method.']
  output.with_suffix('.json').write_text(json.dumps(rows,indent=2,allow_nan=False))
  output.with_suffix('.md').write_text('\n'.join(lines)+'\n')
  print('\n'.join(lines),flush=True)

if __name__=='__main__': main(*sys.argv[1:])
