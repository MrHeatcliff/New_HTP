# Harmony: 22 game Atari còn lại, seed 0

Giữ đúng source/config của run `reborn_harmony_2ew6wt0w` (job3897), xác nhận
SHA256 từng file nguồn đã đóng băng trước submit. Chỉ bổ sung runner cho 22
game; không thêm ablation, không sửa timeout, không tune beta/scalar LR.

Loại Boxing, Up N Down, Frostbite, Road Runner vì đã chạy Harmony. Lưu index
trỏ về checkpoint/evaluation bốn game đó để ghép bảng 26 game sau khi hoàn tất.

Training: Atari100K, size25m, seed0, action repeat4, exact100000 agent actions,
Harmony bật, beta1e-5, unit noise, q_weight0.1. Lưu checkpoint mỗi10K actions.
Các config môi trường và method kế thừa nguyên snapshot trước. Giữ logger
training episode scores theo agent_actions và metric harmonizer như trước.

Evaluation độc lập: seed0, một env; 10 episode/checkpoint tại10K–90K và100
episode tại100K; cùng arm harmony, xác nhận hash checkpoint trước/sau, số
episode và return hữu hạn. 22game tạo220 điểm evaluation và4180 episode.
Không train lại4game, không thêm representation/GPU ablation trong suite này.

Đối chiếu DreamerV3: nguồn W&B hiện có là training returns5seed, bin5K.
Có thể vẽ training-vs-training bằng cùng binning. Evaluation curve Harmony
dùng lịch checkpoint như báo cáo CoRe-WM trước; không được đổi nhãn đường
DreamerV3 thành isolated evaluation. Seed0 không có CI giữa training seed.
Không gọi đây là kiến trúc/parameter-matched DreamerV3.

Một job2H200, 32CPU, 8CPU/game, tối đa4game cùng lúc. Mỗi slot thực hiện train
rồi eval một game trước khi lấy game tiếp; hai slot trên mỗi GPU. Test GPU
chạy trong allocation trước training. Nếu job3897 còn chạy, dependency
afterany:3897 tránh chồng hai allocation nghiên cứu này. Không can thiệp job khác.

Dự kiến12–24h sau khi allocation bắt đầu, có thể lâu hơn nếu nhiều episode
chạm giới hạn thời gian; Slurm time limit48h. Mỗi game có stage.json, command,
train/eval log, source provenance. Một game lỗi được ghi riêng; các slot còn
lại tiếp tục, status cuối FAILED nếu chưa đủ22game hợp lệ. Không xóa checkpoint.
