# Reborn theo hướng HarmonyDream: cơ sở toán và giả thuyết có thể bác bỏ

Ngày: 2026-09-12. Đây là phân tích và protocol đề xuất; chưa implement harmonizer
vào training, chưa submit thí nghiệm mới và chưa có bằng chứng nó cải thiện Reborn.

## 1. Nguồn và phạm vi kết luận

[HarmonyDream, ICML 2024, Sec. 3, Eq. 4–5](https://arxiv.org/pdf/2310.00344)
điều chỉnh trọng số các task observation/reward/dynamics trong world model.
Nó học scalar dương cho từng task. Paper không phải định lý rằng mọi
reconstruction đều gây hại actor–critic hoặc rằng cosine gradient trở nên dương.

[Harmonizer chính thức](https://github.com/thuml/HarmonyDream/blob/main/dreamerv3-jax/dreamerv3/nets.py)
dùng scalar s khởi tạo 0, loss nhân exp(−s), regularizer log(1+exp(s)).
[Agent chính thức](https://github.com/thuml/HarmonyDream/blob/main/dreamerv3-jax/dreamerv3/agent.py)
áp dụng harmonizer cho reward, image và dynamics; actor/critic không phải
các task đầu vào của harmonizer này. Khi port, cần giữ rõ khác biệt giữa
loss balancing và cơ chế sửa hướng gradient.

Các suy luận từ đây là phân tích riêng cho code và thí nghiệm Reborn.

## 2. Có hai vị trí chia sẻ representation, không phải một cặp loss duy nhất

Ký hiệu backbone h_theta, projection mu_psi(h), z=mu+epsilon. Hiện tại
`reborn.grad_to_backbone=false`, `reward_grad=true`, `repval_grad=true`.

| Loss | Trực tiếp cập nhật backbone theta | Trực tiếp cập nhật projection psi |
|---|---|---|
| Decoder ảnh Dreamer gốc | Có | Không |
| Haar reconstruction | Không: auxiliary detach h | Có |
| SF/Q auxiliary | Không: auxiliary detach h | Có |
| Rate | Không trên nhánh auxiliary | Có |
| Reward/continuation Dreamer | Có | Có |
| Imagined actor/critic | Backbone state bị detach trong imagination | Có |
| Replay critic | Có với repval_grad=true | Có |

File: `dreamerv3/agent_reborn.py::loss`, `auxiliary`, `imagine_codes`;
`dreamerv3/agent_htp.py::imag_loss`, `repl_loss`. Bảng nói về gradient của
minibatch hiện tại; không phủ định tác động gián tiếp qua policy/data về sau.

Do decoder gốc không dùng projection:

$$\nabla_\psi L_{\mathrm{base-image}}=0.$$

Do auxiliary detach backbone:

$$\nabla_\theta L_{\mathrm{Haar}}=
\nabla_\theta L_{\mathrm{SF}}=
\nabla_\theta L_Q=0.$$

Harmony ở base-image/reward chủ yếu kiểm tra bài toán backbone. Harmony ở
Haar/SF/reward/Q kiểm tra bài toán projected representation. Không thay cả
hai trong một arm nếu muốn xác định nguyên nhân. Không cần bật gradient
auxiliary về backbone chỉ để harmonizer hoạt động trên psi.

## 3. Phân tích stationary point của harmonizer

Đặt m=E[L]>0, giữ parameters model và phân phối dữ liệu cố định. Viết dạng
rectified từ Eq. 5 với sigma=exp(s):

$$F(m,s)=m e^{-s}+\log(1+e^s).$$

Đạo hàm theo s:

$$\partial_s F=-m e^{-s}+\frac{e^s}{1+e^s},$$

$$\partial_s^2F=m e^{-s}+\frac{e^s}{(1+e^s)^2}>0.$$

Do đó có stationary minimum duy nhất hữu hạn khi m>0. Giải theo sigma:

$$\sigma^2=m(1+\sigma),\qquad
\sigma^*(m)=\frac{m+\sqrt{m^2+4m}}{2},$$

$$w^*(m)=\frac1{\sigma^*}
=\frac{\sqrt{1+4/m}-1}{2}.$$

Vì vậy m rất nhỏ cho w xấp xỉ 1/sqrt(m); m rất lớn cho w xấp xỉ 1/m.
Rectification làm weight tăng chậm hơn inverse-loss thông thường ở vùng
loss nhỏ; nó **không đặt hard upper bound**: w vẫn tiến vô hạn khi m→0.
Nếu m=0, infimum đạt khi s→−infinity, không có finite optimum.

Đóng góp scalar ở stationary point:

$$w^*m=\frac{2}{1+\sqrt{1+4/m}}<1.$$

Giá trị này phụ thuộc m, không phải mọi weighted loss đều bằng nhau.
Khi training, m và policy liên tục thay đổi; s được học bằng optimizer,
không mặc nhiên nằm ở stationary point. Công thức trên là reference diagnostic,
không phải khẳng định hội tụ neural RL.

## 4. Loss balancing không tương đương gradient balancing

Với weight giữ cố định khi lấy gradient model:

$$\nabla_\psi F(L_i,s_i)=w_i g_i,
\qquad g_i=\nabla_\psi L_i.$$

Cho hai task observation và task-relevant prediction, bước SGD lý tưởng:

$$\Delta\psi=-\eta(w_o g_o+w_t g_t).$$

Taylor bậc nhất của task loss:

$$\Delta L_t\approx-\eta\left(w_t\|g_t\|^2+w_o g_t^\top g_o\right).$$

Nếu inner product âm, descent ở L_t yêu cầu:

$$\frac{w_o}{w_t}<\frac{\|g_t\|^2}{-g_t^\top g_o}.$$

Harmonizer thay đổi tỷ lệ weight nên có thể giúp vượt qua điều kiện này,
nhưng không đo trực tiếp vế phải và không bảo đảm bất đẳng thức. Nhân scalar
dương cũng không thay đổi cosine của chính cặp gradient:

$$\cos(w_o g_o,w_t g_t)=\cos(g_o,g_t).$$

Với nhiều loss, dùng g=sum_i w_i g_i, local actor–critic interference là
g_AC^T g. AGC/Adam thực tế còn biến đổi gradient; nếu dùng preconditioner P
cố định, biểu thức đúng là g_AC^T P g. Không gọi cosine Euclidean trước AGC
là tác động optimizer đã thực hiện. Audit hiện tại còn chỉ ở checkpoint cuối.

Hai bài toán có cùng m_i nhưng norm gradient khác nhau vẫn nhận weight giống
nhau. Vì thế lợi ích cần kiểm tra là cải thiện phân bổ task và control, không
phải ép norm hoặc cosine theo một hình dạng định sẵn.

## 5. Dữ liệu hiện tại phản bác cách áp dụng máy móc

Full Boxing, norm gradient weighted trên projection trong shared-state audit:
Haar 0,00052; SF 0,00012; Q 0,04010; reward 0,31947; actor 0,03222;
imagined critic 0,11021. Cosine Q với tổng actor/critics khoảng +0,118.

Tại checkpoint cuối, bằng chứng không phải reconstruction đang áp đảo mọi
task. Nếu harmonize theo loss scale, direction hợp lý có thể là tăng tương
đối observation-grounded gradient, không phải tiếp tục giảm reconstruction.
Norm nhỏ cũng có thể do reconstruction đã hội tụ; tăng nó có thể chỉ đẩy
model theo noise/chi tiết không cần cho task. Đó là hypothesis cần thử.

Minh họa algebra dùng raw scalar loss làm m, không phải dự đoán runtime:
với m_o=0,002, m_t=0,7, stationary weights khoảng 21,87 và 0,80.
Relative observation/task weight tăng khoảng 27 lần. Không được thay m_t
bằng 0,07 rồi nhân q_weight=0,1 thêm lần nữa: placement coefficient là một
phần của objective phải ghi rõ.

Nguồn local: `paper_artifacts/reborn_hypothesis_results/shared_state_audits.json`,
`summary.csv`, `diagnostics.json` và logs của job 3854.

## 6. Hypothesis đề xuất và formulation tối thiểu

**H-Harmony:** fixed weights làm tỷ lệ đóng góp giữa observation-grounded
prediction và reward-grounded prediction thay đổi không phù hợp qua training.
Adaptive weights có thể giúp giữ thông tin hữu ích cho policy trong stochastic
code, dù từng reconstruction head đã khớp coarse-to-fine tốt.

Định nghĩa hai task không âm, theo loss reduction hiện tại:

$$L_O=\lambda_{rec}L_{Haar}+\lambda_{out}L_{SF},$$

$$L_T=\lambda_{rew}L_{rew}+\lambda_{out}\lambda_Q L_Q.$$

L_SF, L_Q là trung bình trên level và valid transitions; L_Q ở đây là CE
chưa nhân q_weight. L_rew là loss reward thật hiện tại, L_Q là auxiliary
action-value. Không cộng đôi các terms đã weighted trong implementation.

Phần còn lại L_fixed gồm base image, dyn/rep, continuation, actor, imagined
critic, replay critic với coefficient cũ; loại L_rew khỏi phần này vì đã ở L_T.
Đặt beta_eff=lambda_rec beta theo đúng code hiện tại. Bản đề xuất:

$$\boxed{L_{new}=L_{fixed}+\beta_{eff}R+
F(L_O,s_O)+F(L_T,s_T).}$$

Chỉ hai scalar mới. Group SF cùng Haar vì đều neo bằng observation; Q cùng
reward vì đều neo bằng reward. Group này là đề xuất của chúng ta, không phải
copy nguyên paper. Một scalar observation chung tránh tự ý đổi weight từng
Haar band và phá diễn giải distortion Parseval ban đầu.

s_O=s_T=0 cho cùng model gradient ban đầu như fixed weights, regularizer chỉ
thêm hằng tại khởi tạo. Nhưng cần theo dõi tốc độ học s: LR model hiện 4e-5
và khoảng 25K updates không bảo đảm weights tới stationary reference. Chưa
chọn scalar LR là tối ưu; đo tracking trước khi tune, tránh thay LR backbone.
Implement stable regularizer bằng softplus(s), không log(exp(s)+1) trực tiếp.

### Vì sao giữ actor loss bên ngoài

Policy-gradient surrogate có thể âm và phụ thuộc baseline advantage. Nếu
E[L_actor]<0 thì F(E[L_actor],s)→−infinity khi s→−infinity. Vì vậy không thể
áp dụng nguyên harmonizer cho signed actor objective. Cộng hằng để làm dương
cũng tùy tiện thay đổi learned weight dù gradient actor không đổi.
Critic twohot không âm nhưng gom cả critic vào đây là một thay đổi khác;
vòng đầu giữ actor/critic coefficient cũ để kiểm tra tác động gián tiếp.

### Rate phải được quan sát như một tradeoff thay đổi

Giữ beta bên ngoài tránh tự động học lại chi phí thông tin như task error.
Tuy nhiên relative compression vẫn đổi khi weights đổi:

$$\beta_{relative,O}=\frac{\beta_{eff}}{w_O\lambda_{rec}}.$$

Nếu w_O tăng, beta tương đối giảm. Do đó performance tăng có thể là tác dụng
giống low_rate, chưa chứng minh task harmonization. Phải log tỷ lệ này và
giữ arm low_rate đã có làm reference; cần rate-matched control ở vòng xác nhận.
Không tuyên bố cố định beta đồng nghĩa cố định effective bottleneck.

## 7. Hai nhạy cảm toán học cần kiểm tra trước claim

### Normalization

Với loss cL, gradient model ở stationary point là c w*(cm) g.
Ở vùng cm nhỏ, nó xấp xỉ sqrt(c/m) g, phụ thuộc sqrt(c). Rectified harmonizer
không invariant với phép nhân normalization. Không đổi sum/mean, số pixels,
average level hoặc đặt lambda vào/ngoài F tùy tiện trong cùng thí nghiệm.

### Irreducible loss và hằng số

L'=L+c có cùng gradient nhưng harmonizer học w*(m+c) khác w*(m).
Twohot CE chứa entropy của target; MSE với observation và stochastic code có
noise floor. Harmonizer không biết đâu là error giảm được, đâu là hằng nền.
Ví dụ CE(y,p)=KL(y||p)+H(y), target detach. Bỏ H(y) không đổi gradient head
nhưng đổi adaptive weighting. Vòng đầu giữ CE nguyên để chỉ đổi balancing;
log target entropy và KL excess nhằm phân biệt cơ chế, không thay ngầm loss.

## 8. Protocol để kiểm chứng

Vòng đầu giữ noise std=1, beta=1e-5, Q bật, backbone detach route và tất cả
optimizer/head như Full. Chỉ đổi fixed weights thành hai harmonizer trên.
Không kết hợp giảm beta hay bỏ noise cùng arm harmony.

Bốn game, hai GPU, hai game/GPU, tám CPU/game; một job với các wave tuần tự.
Để tránh lặp lại kết luận từ một training seed, đề xuất paired seeds 0,1,2
cho Full và Harmony (24 run); đây là kế hoạch, chưa submit allocation.
Nếu cần screening trước, seed0 hai arm chỉ cho quyết định có đáng mở rộng hay
không; không dùng episode CI thay training-seed uncertainty.

Trước mở rộng: audit reproducibility vì Full seed0 đã phân kỳ ở các run cũ.
Source frozen, matched data/PRNG ở diagnostic, kiểm tra counts updates và
report calls theo step; không kết luận same seed là same trajectory.

Log theo checkpoint 10K/30K/60K/100K thay vì chỉ cuối:

- s, w, raw/weighted task loss, stationary reference từ EMA detached của loss,
  gradient theo s và mức tracking; percent clipping nếu sau này có numerical cap.
- beta_relative,O, block/prefix rate, variance mu, sampled-code utility.
- gradient rec/SF/reward/Q/actor/critics tại psi và base-image/reward ở theta;
  norm trước/sau AGC hoặc realized update diagnostic nếu khả thi.
- paired noise TV/KL, action flip, value/reward change trên shared trajectories.
- held-out prediction error, CE target entropy/excess; frozen-policy real
  returns để đánh giá Q/critic, kèm coverage terminal và censoring.
- isolated checkpoint eval 10 episodes/mốc, final 100 episodes; AUC và seed-level
  dispersion. Giữ và kiểm tra hash checkpoint.

Ủng hộ H-Harmony khi adaptive weights cải thiện prediction hữu ích và control
nhất quán, không chỉ nâng reconstruction hoặc làm weighted losses trông cân.
Phản bác nếu weights đổi nhưng control không tốt hơn, hoặc tăng observation
gradient chỉ học thêm chi tiết không liên quan. Nếu lợi ích chỉ tương đương
giảm beta, cần chẩn đoán đó là effective-rate effect. Nếu cosine vẫn âm nhưng
score tăng, điều đó không mâu thuẫn cơ chế loss balancing.

## 9. Kết luận nghiên cứu hiện tại

HarmonyDream là cơ sở hợp lý để thay fixed weights bằng adaptive task weights.
Ứng dụng vào Reborn cần đặt đúng vị trí chia sẻ projection, giữ signed actor
loss bên ngoài, kiểm soát effective beta và loss floor. Đây là một giả thuyết
có cơ sở toán học và thí nghiệm bác bỏ được, chưa là guarantee cải thiện control.
