# Reborn Harmony: screening được triển khai

Hai arm Full và Harmony, mỗi arm bốn game Boxing, Up N Down, Frostbite,
Road Runner, seed0, 100K actions. Hai wave tuần tự trong một allocation hai
H200, hai game/GPU, tám CPU/game. Đây là screening trước khi mở rộng nhiều
seed, không phải thí nghiệm xác nhận 24 run trong đề xuất dài hạn.

## Objective và biến được giữ cố định

Harmony có hai scalar s khởi tạo 0, weight exp(−s), regularizer softplus(s).
Task observation = lambda_rec Haar + lambda_out SF; task reward = lambda_rew
reward thật + lambda_out q_weight Q. Rate, continuation, backbone image/KL và
actor/critics giữ coefficient cũ. Beta=1e-5, noise std=1, q_weight=0.1,
gradient auxiliary về backbone vẫn tắt. Không nhân q_weight hai lần.

Scalars cùng optimizer và LR4e-5 như model, không thêm scalar-LR hyperparam.
Khởi tạo cho model gradient như Full, tổng loss thêm 2 log2. Theo dõi weight
tracking vì 25K updates có thể chưa đủ để đạt stationary value. Stationary
reference từ minibatch chỉ là diagnostic tức thời, không phải EMA equilibrium.

Giả thuyết: adaptive observation/reward weighting cải thiện projected features
hữu ích cho policy. Không mặc định reconstruction đang thống trị; weight có
thể tăng observation tương đối. Nếu weights không đổi đáng kể, kết quả âm
chưa đủ bác bỏ ý tưởng; trước hết kiểm tra gradient scalar/tốc độ thích nghi.
Nếu cải thiện đi kèm beta tương đối giảm, phải phân biệt với effective-rate effect.

## Logs

- harmony/{observation,task}/{raw,weight,log_scale,weighted,scalar_gradient,
  stationary_weight_batch}.
- harmony/effective_beta_observation = beta / observation_weight.
- harmony/actual_{rec,sf,q,reward}: đóng góp thật sau harmonization;
  weighted_loss cũ vẫn là coefficient danh nghĩa, không dùng thay actual.
- loss/total_actual chứa regularizer scalar; training không thêm random draw
  cho metrics mới. Full cũng đi qua cùng instrumentation có thể áp dụng.
- Gradient audit đã nhân đúng adaptive weight cho rec/SF/Q/reward; rate và
  actor/critic không nhân. Không áp dụng harmonizer cho signed actor loss.

Audit trên Full final-policy clips dùng chung ở checkpoints 10K/30K/60K/100K.
Đây là fixed-distribution post-hoc audit, không phải minibatch training đã dùng
tại thời điểm đó; early checkpoint có thể thấy state ngoài phân phối. Final
còn có own-policy audit và representation/SF/Q/critic diagnostic như suite cũ.
Complete-return critic calibration chỉ trên clip terminal thật.

## Evaluation, kiểm tra, giới hạn

Mỗi checkpoint 10K–90K: 10 episode evaluation riêng. Final100K: 100 episode.
Giữ đúng arm khi load/eval, kiểm tra checkpoint hash và số episode. Không
thay evaluation bằng training return. Không thay noise trong policy evaluation.

Test trong allocation trước training: stationary derivative harmonizer,
model gradient theo weight, khởi tạo objective, actual optimization+EMA và
audit ở cả Full/Harmony. Không chạy JAX/test GPU trên login.

Source đóng băng kèm SHA256 trước submit. Full seed0 chạy lại cùng source vì
reproducibility cũ chưa được xác định hoàn toàn. Một seed không đủ claim;
không tự thay đổi report scheduling/backbone để chữa reproducibility trong
arm này. Dự kiến 4–8 giờ cho training, evaluation và multi-checkpoint audit;
time limit24h. Không tự động push hoặc monitor lâu dài sau khi khởi chạy.

Nền toán và rủi ro: [REBORN_HARMONY_ANALYSIS_VI.md](REBORN_HARMONY_ANALYSIS_VI.md).
