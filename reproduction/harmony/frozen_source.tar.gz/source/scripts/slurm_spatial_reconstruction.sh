#!/usr/bin/env bash
#SBATCH --job-name=spatial-reconstruction
#SBATCH --partition=gpu_junior
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --gres=gpu:nvidia_h200:2
#SBATCH --mem=256G
#SBATCH --time=12:00:00
#SBATCH --output=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/spatial-%j.out
#SBATCH --error=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/spatial-%j.err
set -euo pipefail
: "${SLURM_JOB_ID:?Slurm required}"
readonly RUNROOT="${1:?Frozen source root}"
export HTP_RESEARCH_REPO=/home/vn-user0101/Dat/HTS-Dreamer
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false PYTHONUNBUFFERED=1
cd "$RUNROOT/source"
readonly PYTHON="$HTP_RESEARCH_REPO/.venv/bin/python"
readonly EXPERIMENT_MODE="${HTP_COMPONENT_MODE:-spatial}"
unset HTP_COMPONENT_MODE
"$PYTHON" -m pytest tests/test_spatial_reconstruction.py tests/test_coarse_reconstruction_target.py tests/test_component_ablation.py tests/test_h200_suite.py -q
export HTP_COMPONENT_MODE="$EXPERIMENT_MODE"
if [[ "$EXPERIMENT_MODE" == constrained_factorial ]]; then
  "$PYTHON" -m corewm_eval.matched_audit_report "$HTP_RESEARCH_REPO/production_runs/component_matched_X1fjitW5" "$RUNROOT/matched_audit_summary"
fi
if [[ "${HTP_COMPONENT_MODE:-spatial}" == spatial_refine ]]; then
  "$PYTHON" -m corewm_eval.spatial_diagnosis "$RUNROOT/prior_diagnosis.json"
  "$PYTHON" -m corewm_eval.spatial_diagnosis "$RUNROOT/seed1_diagnosis.json" spatial_refine_vMknLzBP
fi
export HTP_COMPONENT_MODE="${HTP_COMPONENT_MODE:-spatial}"
exec "$PYTHON" -u -m corewm_eval.component_ablation "$RUNROOT"
