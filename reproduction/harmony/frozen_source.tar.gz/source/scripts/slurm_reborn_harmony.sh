#!/usr/bin/env bash
#SBATCH --job-name=reborn-harmony
#SBATCH --partition=gpu_general
#SBATCH --qos=gpu_general_qos
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --gres=gpu:nvidia_h200:2
#SBATCH --mem=192G
#SBATCH --time=24:00:00
#SBATCH --output=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/reborn-harmony-%j.out
#SBATCH --error=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/reborn-harmony-%j.err
set -euo pipefail
readonly RUNROOT="${1:?Frozen run root}"
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=8
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export REBORN_ARMS=full,harmony
export REBORN_AUDIT_MILESTONES=10000,30000,60000
cd "$RUNROOT/source"
exec /home/vn-user0101/Dat/HTS-Dreamer/.venv/bin/python -u -m corewm_eval.reborn_hypothesis_suite "$RUNROOT"
