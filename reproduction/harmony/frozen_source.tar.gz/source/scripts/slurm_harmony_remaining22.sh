#!/usr/bin/env bash
#SBATCH --job-name=harmony-remaining22
#SBATCH --partition=gpu_general
#SBATCH --qos=gpu_general_qos
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --gres=gpu:nvidia_h200:2
#SBATCH --mem=192G
#SBATCH --time=2-00:00:00
#SBATCH --output=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/harmony-remaining22-%j.out
#SBATCH --error=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/harmony-remaining22-%j.err
set -euo pipefail
readonly RUNROOT="${1:?Frozen run root}"
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=8
export XLA_PYTHON_CLIENT_PREALLOCATE=false
cd "$RUNROOT/source"
exec /home/vn-user0101/Dat/HTS-Dreamer/.venv/bin/python -u -m corewm_eval.harmony_remaining22 "$RUNROOT"
