"""Freeze reviewed source and submit one 1-GPU, two-game allocation."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

repo = Path(__file__).resolve().parents[1]
root = Path(tempfile.mkdtemp(prefix='reborn_two_game_', dir=repo/'production_runs'))
source = root/'source'; source.mkdir()
files = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard',
    'dreamerv3','embodied','corewm_eval','tests','scripts','requirements.txt','baselines.yaml',
    'paper_artifacts/persistence_research/REBORN_PROTOCOL_VI.md'], cwd=repo, text=True).splitlines()
manifest = {}
for name in sorted(set(files)):
  original = repo/name
  if not original.is_file():
    continue
  target = source/name
  target.parent.mkdir(parents=True, exist_ok=True)
  shutil.copy2(original,target)
  manifest[name] = hashlib.sha256(target.read_bytes()).hexdigest()
(root/'source_sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
job = subprocess.check_output(['sbatch','--parsable',
    str(source/'scripts/slurm_reborn_two_games.sh'),str(root)], cwd=repo,text=True).strip()
(root/'submission.json').write_text(json.dumps(dict(job_id=job, games=['boxing','frostbite'],
    gpus=1,cpus_per_game=8,replaces_cancelled_job='3843',root=str(root),branch='reborn'),indent=2)+'\n')
print(json.dumps(dict(job_id=job,root=str(root)),indent=2))
