"""Submit one 2-H200 allocation, retaining the exact seed-0 method snapshot."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
  repo = Path(__file__).resolve().parents[1]
  prior = repo/'production_runs/harmony_remaining22_zvn1urx5'
  assert json.loads((prior/'status.json').read_text())['status'] == 'COMPLETE'
  root = Path(tempfile.mkdtemp(prefix='harmony_seeds1to4_', dir=repo/'production_runs'))
  source = root/'source'
  shutil.copytree(prior/'source', source)
  for name in ('corewm_eval/harmony_multiseed.py', 'scripts/slurm_harmony_multiseed.sh',
               'scripts/submit_harmony_multiseed.py'):
    shutil.copy2(repo/name, source/name)
  hashes = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in source.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
  old = json.loads((prior/'source_sha256.json').read_text())
  for name, digest in old.items():
    if '__pycache__' in Path(name).parts:
      continue  # Runtime bytecode is not immutable model source.
    assert hashes[name] == digest, f'Frozen source changed: {name}'
  (root/'source_sha256.json').write_text(json.dumps(hashes, indent=2)+'\n')
  cmd = ['sbatch', '--parsable', str(source/'scripts/slurm_harmony_multiseed.sh'), str(root)]
  job = subprocess.check_output(cmd, cwd=repo, text=True).strip()
  record = dict(job_id=job, root=str(root), prior=str(prior), command=cmd,
      training_seeds=[1,2,3,4], games=26, runs=104, evaluation_seed=0,
      gpus=2, concurrent_games=4, cpus_per_game=8,
      method_source_verified_identical=True, expected_hours_after_start=[36,46])
  (root/'submission.json').write_text(json.dumps(record, indent=2)+'\n')
  print(json.dumps(record, indent=2))


if __name__ == '__main__':
  main()
