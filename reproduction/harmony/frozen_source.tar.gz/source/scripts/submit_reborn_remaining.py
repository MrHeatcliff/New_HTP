"""Freeze source and submit one general-QOS job for the remaining two games."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

repo = Path(__file__).resolve().parents[1]
root = Path(tempfile.mkdtemp(prefix='reborn_two_remaining_', dir=repo/'production_runs'))
source = root/'source'; source.mkdir()
files = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard',
    'dreamerv3','embodied','corewm_eval','tests','scripts','requirements.txt','baselines.yaml',
    'paper_artifacts/persistence_research/REBORN_PROTOCOL_VI.md'], cwd=repo,text=True).splitlines()
hashes = {}
for name in sorted(set(files)):
  original = repo/name
  if not original.is_file():
    continue
  target = source/name
  target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(original,target)
  hashes[name] = hashlib.sha256(target.read_bytes()).hexdigest()
(root/'source_sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
job = subprocess.check_output(['sbatch','--parsable',
    str(source/'scripts/slurm_reborn_two_games_remaining.sh'),str(root)],cwd=repo,text=True).strip()
(root/'submission.json').write_text(json.dumps(dict(job_id=job,
    games=['up_n_down','road_runner'],gpus=1,cpus_per_game=8,
    partition='gpu_general',qos='gpu_general_qos',root=str(root),branch='reborn'),indent=2)+'\n')
print(json.dumps(dict(job_id=job,root=str(root)),indent=2))
