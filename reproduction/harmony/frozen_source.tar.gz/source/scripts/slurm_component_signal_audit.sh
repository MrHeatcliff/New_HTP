#!/usr/bin/env bash
#SBATCH --job-name=component-signal-audit
#SBATCH --partition=gpu_junior
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --gres=gpu:nvidia_h200:2
#SBATCH --mem=256G
#SBATCH --time=08:00:00
#SBATCH --output=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/component-audit-%j.out
#SBATCH --error=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/component-audit-%j.err
set -euo pipefail
: "${SLURM_JOB_ID:?Slurm required}"
readonly RUNROOT="${1:?Frozen source root}"
export HTP_RESEARCH_REPO=/home/vn-user0101/Dat/HTS-Dreamer
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false PYTHONUNBUFFERED=1
unset HTP_COMPONENT_MODE
cd "$RUNROOT/source"
readonly PYTHON="$HTP_RESEARCH_REPO/.venv/bin/python"
"$PYTHON" -m pytest tests/test_component_signal_audit.py tests/test_pdyn_episode_mask.py tests/test_h200_suite.py -q
if [[ "${HTP_MATCHED_AUDIT:-0}" == 1 ]]; then
  "$PYTHON" -m corewm_eval.component_audit_report "$HTP_RESEARCH_REPO/production_runs/component_signal_jK5S0xLS" "$RUNROOT/prior_summary"
fi
exec "$PYTHON" -u -m corewm_eval.component_signal_audit "$RUNROOT"
