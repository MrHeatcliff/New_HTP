"""Reuse previous immutable model source; add only a train/eval scheduler."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

repo=Path(__file__).resolve().parents[1]
prior=repo/'production_runs/reborn_harmony_2ew6wt0w'
root=Path(tempfile.mkdtemp(prefix='harmony_remaining22_',dir=repo/'production_runs'))
source=root/'source';shutil.copytree(prior/'source',source)
for name in ('corewm_eval/harmony_remaining22.py','scripts/slurm_harmony_remaining22.sh',
    'scripts/submit_harmony_remaining22.py','paper_artifacts/persistence_research/HARMONY_REMAINING22_VI.md'):
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target)
hashes={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in source.rglob('*') if p.is_file()}
old=json.loads((prior/'source_sha256.json').read_text())
for name,digest in old.items():
  assert hashes[name]==digest, f'Frozen source changed: {name}'
(root/'source_sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
excluded=('boxing','up_n_down','frostbite','road_runner')
(root/'existing_four_games.json').write_text(json.dumps({g:dict(
    training=str(prior/'harmony'/g/'full'),evaluation=str(prior/'harmony/evaluation'/g))
    for g in excluded},indent=2)+'\n')
active=subprocess.check_output(['squeue','-h','-j','3897','-o','%T'],text=True).strip()
cmd=['sbatch','--parsable']
if active:cmd+=['--dependency=afterany:3897']
cmd+=[str(source/'scripts/slurm_harmony_remaining22.sh'),str(root)]
job=subprocess.check_output(cmd,cwd=repo,text=True).strip()
record=dict(job_id=job,root=str(root),prior=str(prior),gpus=2,cpus_per_game=8,
    training_seed=0,excluded=excluded,dependency='afterany:3897' if active else None,
    method_source_verified_identical=True,command=cmd)
(root/'submission.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
