#!/usr/bin/env bash
#SBATCH --job-name=reborn-two-game
#SBATCH --partition=gpu_junior
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --gres=gpu:nvidia_h200:1
#SBATCH --mem=128G
#SBATCH --time=08:00:00
#SBATCH --output=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/reborn-two-%j.out
#SBATCH --error=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/reborn-two-%j.err
set -euo pipefail
: "${SLURM_JOB_ID:?Slurm required}"
readonly RUNROOT="${1:?Frozen run root}"
readonly PYTHON=/home/vn-user0101/Dat/HTS-Dreamer/.venv/bin/python
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false PYTHONUNBUFFERED=1
export REBORN_GAMES=boxing,frostbite
cd "$RUNROOT/source"
"$PYTHON" -m pytest tests/test_reborn.py tests/test_h200_suite.py -q > "$RUNROOT/tests.log" 2>&1
exec "$PYTHON" -u -m corewm_eval.reborn_experiment "$RUNROOT"
