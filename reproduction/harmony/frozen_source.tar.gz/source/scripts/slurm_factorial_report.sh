#!/usr/bin/env bash
#SBATCH --job-name=factorial-report
#SBATCH --partition=cpu_general
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=00:20:00
#SBATCH --output=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/factorial-report-%j.out
#SBATCH --error=/home/vn-user0101/Dat/HTS-Dreamer/slurm_logs/factorial-report-%j.err
set -euo pipefail
: "${SLURM_JOB_ID:?Slurm required}"
cd /home/vn-user0101/Dat/HTS-Dreamer
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
exec .venv/bin/python -m corewm_eval.factorial_report \
  production_runs/constrained_factorial_NOBwTnNw \
  production_runs/constrained_factorial_NOBwTnNw/factorial_summary.json
