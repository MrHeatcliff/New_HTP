import jax.numpy as jnp
import ninjax as nj
import numpy as np
from dreamerv3.htp import ProgressiveRecon


def test_pyramid_changes_coarse_targets_but_not_parameters_or_full_target():
  z = jnp.ones((1, 2, 10), jnp.bfloat16)
  image = (jnp.arange(64)[:, None] + jnp.arange(64)[None, :]) % 2
  target = jnp.broadcast_to(image[None, None, ..., None], (1, 2, 64, 64, 3)).reshape(1, 2, -1).astype(jnp.float32)
  args = dict(feat_dim=12288, dims=(2,4,6,8,10), layers=0, hidden=8,
              image_target=True, outscale=0., name='rec')
  uniform = ProgressiveRecon(**args)
  pyramid = ProgressiveRecon(**args, spatial_pyramid=True)
  params, (_, original) = nj.pure(lambda: uniform(z, target))({}, seed=0, create=True)
  other, (_, coarse) = nj.pure(lambda: pyramid(z, target))(params, seed=0, create=False, modify=False)
  assert set(params) == set(other)
  np.testing.assert_allclose(original[-1], coarse[-1])
  assert float(coarse[0].mean()) < float(original[0].mean())
  soft = ProgressiveRecon(**args, spatial_pyramid=True, pyramid_min_size=8)
  soft_params, (_, soft_loss) = nj.pure(lambda: soft(z, target))(params, seed=0, create=False, modify=False)
  assert set(soft_params) == set(params)
  np.testing.assert_allclose(soft_loss[-1], original[-1])


def test_spatial_probe_target_preserves_cells_and_episode_alignment(tmp_path):
  from corewm_eval.four_game_representation import spatial_targets
  cells = np.arange(64, dtype=np.uint8).reshape(8, 8)
  image = np.repeat(np.repeat(cells, 8, axis=0), 8, axis=1)
  image = np.repeat(image[..., None], 3, axis=-1)
  for eid in (1, 0):
    np.savez(tmp_path / f'episode_{eid:02d}.npz', observation=image[None],
             episode_id=np.array([eid]), timestep=np.array([0]))
  target, ids, times = spatial_targets(tmp_path)
  np.testing.assert_allclose(target[0].reshape(8, 8, 3)[..., 0], cells / 255.)
  np.testing.assert_array_equal(ids, [0, 1])
  np.testing.assert_array_equal(times, [0, 0])


def test_spatial_replication_keeps_constraint_and_target_only_contrast(monkeypatch):
  from corewm_eval import component_ablation as ab
  monkeypatch.setattr(ab, 'MODE', 'spatial_refine')
  monkeypatch.setattr(ab, 'ARMS', dict.fromkeys(['image_uniform', 'image_pyramid', 'image_soft'], (True, True)))
  monkeypatch.setenv('HTP_TRIAL_SEED', '2')
  old, soft = [ab.command('boxing', arm, '/tmp/same') for arm in ('image_pyramid', 'image_soft')]
  assert soft[soft.index('--seed') + 1] == '2'
  assert soft[soft.index('--agent.htp.persistence_scale') + 1] == '0.1'
  assert soft[soft.index('--agent.htp.persistence_isotropy') + 1] == '0.01'
  assert soft[soft.index('--agent.htp.recon.pyramid_min_size') + 1] == '8'
  soft[soft.index('--agent.htp.recon.pyramid_min_size') + 1] = '4'
  assert old == soft
