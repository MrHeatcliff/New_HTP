import numpy as np
from corewm_eval.component_signal_audit import head_errors, intervention_metrics


def test_reward_strata_expose_zero_predictor_failure():
  head = {'reward':np.zeros((1,4)), 'con':np.full((1,4),.99), 'entropy':np.zeros((1,4))}
  result = head_errors(head, np.array([0,0,0,10]), np.zeros(4,bool), .99)
  assert result['reward_mae'] == 2.5
  assert result['nonzero_reward']['reward_mae'] == 10
  assert result['zero_reward']['reward_mae'] == 0
  assert result['terminal']['count'] == 0
  assert result['terminal']['continuation_brier'] is None
  assert result['continuation_brier_training_target'] == 0


def test_continuation_uses_discounted_terminal_target():
  head = {'reward':np.zeros((1,2)), 'con':np.array([[.99,0]]), 'entropy':np.zeros((1,2))}
  result = head_errors(head,np.zeros(2),np.array([False,True]),.99)
  assert result['terminal']['count'] == 1
  assert result['continuation_brier_training_target'] == 0


def test_block_reliance_identity_and_action_reversal():
  a = {'policy':np.array([[[.9,.1]]]),'reward':np.zeros((1,1)),'value':np.zeros((1,1))}
  assert intervention_metrics(a,a)['actor_kl'] == 0
  b = dict(a,policy=np.array([[[.1,.9]]]))
  result = intervention_metrics(a,b)
  assert result['greedy_action_change'] == 1
  np.testing.assert_allclose(result['actor_kl'], .8*np.log(9))
